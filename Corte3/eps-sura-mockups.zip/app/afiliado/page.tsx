'use client'

import Link from 'next/link'
import { useAuth } from '@/lib/auth-context'
import { citas, autorizaciones, medicamentos, resultadosExamenes } from '@/lib/mock-data'
import {
  Calendar,
  FileText,
  Pill,
  ClipboardList,
  ChevronRight,
  Clock,
  MapPin,
  User,
  AlertCircle,
  CheckCircle2,
  Bell
} from 'lucide-react'

export default function AfiliadoDashboard() {
  const { user } = useAuth()

  const userCitas = citas.filter(c => c.pacienteId === user?.id)
  const proximaCita = userCitas.find(c => c.estado === 'confirmada' || c.estado === 'programada')
  const citasHoy = userCitas.filter(c => c.fecha === '2026-04-25')
  
  const userAutorizaciones = autorizaciones.filter(a => a.pacienteId === user?.id)
  const autorizacionesPendientes = userAutorizaciones.filter(a => a.estado === 'pendiente')
  
  const userMedicamentos = medicamentos.filter(m => m.estado === 'activo')
  const medicamentosConReclamo = userMedicamentos.filter(m => (m.reclamosPendientes || 0) > 0)
  
  const examenesPendientes = resultadosExamenes.filter(e => e.pacienteId === user?.id && e.estado === 'pendiente')
  const examenesListos = resultadosExamenes.filter(e => e.pacienteId === user?.id && e.estado === 'listo')

  const quickActions = [
    { href: '/afiliado/citas/nueva', icon: Calendar, label: 'Agendar cita', color: 'bg-chart-1' },
    { href: '/afiliado/autorizaciones/nueva', icon: FileText, label: 'Solicitar autorizacion', color: 'bg-chart-2' },
    { href: '/afiliado/medicamentos', icon: Pill, label: 'Ver medicamentos', color: 'bg-chart-3' },
    { href: '/afiliado/historial', icon: ClipboardList, label: 'Historial medico', color: 'bg-chart-4' },
  ]

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="bg-card rounded-2xl p-6 border border-border">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              Hola, {user?.nombre}
            </h1>
            <p className="text-muted-foreground mt-1">
              Bienvenido a tu portal de salud. Aqui puedes gestionar todos tus servicios.
            </p>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="px-3 py-1 bg-primary/10 text-primary rounded-full font-medium">
              {user?.planSalud}
            </span>
            <span className="px-3 py-1 bg-muted text-muted-foreground rounded-full capitalize">
              {user?.tipoAfiliacion}
            </span>
          </div>
        </div>
      </div>

      {/* Alerts Section */}
      {(autorizacionesPendientes.length > 0 || medicamentosConReclamo.length > 0 || examenesListos.length > 0) && (
        <div className="space-y-3">
          {autorizacionesPendientes.length > 0 && (
            <div className="bg-warning/10 border border-warning/20 rounded-xl p-4 flex items-start gap-3">
              <Bell className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-foreground">Autorizaciones pendientes</p>
                <p className="text-sm text-muted-foreground">
                  Tienes {autorizacionesPendientes.length} autorizacion(es) en proceso de revision.
                </p>
              </div>
              <Link href="/afiliado/autorizaciones" className="text-primary text-sm font-medium hover:underline">
                Ver
              </Link>
            </div>
          )}
          
          {medicamentosConReclamo.length > 0 && (
            <div className="bg-accent/10 border border-accent/20 rounded-xl p-4 flex items-start gap-3">
              <Pill className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-foreground">Medicamentos por reclamar</p>
                <p className="text-sm text-muted-foreground">
                  Tienes medicamentos pendientes por recoger en la farmacia.
                </p>
              </div>
              <Link href="/afiliado/medicamentos" className="text-primary text-sm font-medium hover:underline">
                Ver
              </Link>
            </div>
          )}

          {examenesListos.length > 0 && (
            <div className="bg-success/10 border border-success/20 rounded-xl p-4 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-foreground">Resultados disponibles</p>
                <p className="text-sm text-muted-foreground">
                  Tienes {examenesListos.length} resultado(s) de examenes listos para consultar.
                </p>
              </div>
              <Link href="/afiliado/historial" className="text-primary text-sm font-medium hover:underline">
                Ver
              </Link>
            </div>
          )}
        </div>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((action) => (
          <Link
            key={action.href}
            href={action.href}
            className="bg-card border border-border rounded-xl p-5 hover:border-primary/50 hover:shadow-sm transition-all group"
          >
            <div className={`w-12 h-12 ${action.color} rounded-xl flex items-center justify-center mb-4`}>
              <action.icon className="w-6 h-6 text-white" />
            </div>
            <p className="font-semibold text-foreground group-hover:text-primary transition-colors">
              {action.label}
            </p>
          </Link>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Next Appointment */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border flex items-center justify-between">
            <h2 className="font-semibold text-lg text-foreground">Proxima cita</h2>
            <Link href="/afiliado/citas" className="text-primary text-sm font-medium hover:underline flex items-center gap-1">
              Ver todas <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          
          {proximaCita ? (
            <div className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 bg-primary/10 rounded-xl flex flex-col items-center justify-center flex-shrink-0">
                  <span className="text-2xl font-bold text-primary">
                    {new Date(proximaCita.fecha).getDate()}
                  </span>
                  <span className="text-xs text-primary uppercase">
                    {new Date(proximaCita.fecha).toLocaleDateString('es-CO', { month: 'short' })}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground">{proximaCita.especialidad}</h3>
                  <p className="text-muted-foreground text-sm mt-1">{proximaCita.medicoNombre}</p>
                  
                  <div className="flex flex-wrap gap-4 mt-3 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4" />
                      {proximaCita.hora}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin className="w-4 h-4" />
                      {proximaCita.consultorio || 'Virtual'}
                    </span>
                  </div>
                  
                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      proximaCita.estado === 'confirmada' 
                        ? 'bg-success/10 text-success' 
                        : 'bg-warning/10 text-warning'
                    }`}>
                      {proximaCita.estado === 'confirmada' ? 'Confirmada' : 'Por confirmar'}
                    </span>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      proximaCita.tipo === 'presencial' 
                        ? 'bg-muted text-muted-foreground' 
                        : 'bg-chart-3/10 text-chart-3'
                    }`}>
                      {proximaCita.tipo === 'presencial' ? 'Presencial' : 'Virtual'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-6 text-center">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground mb-4">No tienes citas programadas</p>
              <Link
                href="/afiliado/citas/nueva"
                className="inline-flex items-center justify-center px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium text-sm hover:bg-primary/90 transition-colors"
              >
                Agendar cita
              </Link>
            </div>
          )}
        </div>

        {/* Authorizations Status */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border flex items-center justify-between">
            <h2 className="font-semibold text-lg text-foreground">Autorizaciones</h2>
            <Link href="/afiliado/autorizaciones" className="text-primary text-sm font-medium hover:underline flex items-center gap-1">
              Ver todas <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          
          <div className="p-6 space-y-4">
            {userAutorizaciones.slice(0, 3).map((auth) => (
              <div key={auth.id} className="flex items-start gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  auth.estado === 'aprobada' ? 'bg-success/10' :
                  auth.estado === 'pendiente' ? 'bg-warning/10' :
                  auth.estado === 'rechazada' ? 'bg-destructive/10' :
                  'bg-muted'
                }`}>
                  {auth.estado === 'aprobada' ? (
                    <CheckCircle2 className="w-4 h-4 text-success" />
                  ) : auth.estado === 'pendiente' ? (
                    <Clock className="w-4 h-4 text-warning" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-destructive" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground text-sm truncate">{auth.descripcion}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {auth.tipo} - {auth.fechaSolicitud}
                  </p>
                </div>
                <span className={`px-2 py-0.5 rounded text-xs font-medium capitalize flex-shrink-0 ${
                  auth.estado === 'aprobada' ? 'bg-success/10 text-success' :
                  auth.estado === 'pendiente' ? 'bg-warning/10 text-warning' :
                  auth.estado === 'rechazada' ? 'bg-destructive/10 text-destructive' :
                  'bg-muted text-muted-foreground'
                }`}>
                  {auth.estado}
                </span>
              </div>
            ))}
            
            {userAutorizaciones.length === 0 && (
              <p className="text-center text-muted-foreground py-4">
                No tienes autorizaciones recientes
              </p>
            )}
          </div>
        </div>

        {/* Active Medications */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border flex items-center justify-between">
            <h2 className="font-semibold text-lg text-foreground">Medicamentos activos</h2>
            <Link href="/afiliado/medicamentos" className="text-primary text-sm font-medium hover:underline flex items-center gap-1">
              Ver todos <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          
          <div className="p-6 space-y-4">
            {userMedicamentos.slice(0, 3).map((med) => (
              <div key={med.id} className="flex items-start gap-3">
                <div className="w-10 h-10 bg-chart-3/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Pill className="w-5 h-5 text-chart-3" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground">{med.nombre}</p>
                  <p className="text-sm text-muted-foreground">{med.dosis} - {med.frecuencia}</p>
                  {(med.reclamosPendientes || 0) > 0 && (
                    <p className="text-xs text-accent font-medium mt-1">
                      {med.reclamosPendientes} reclamo(s) pendiente(s)
                    </p>
                  )}
                </div>
              </div>
            ))}
            
            {userMedicamentos.length === 0 && (
              <p className="text-center text-muted-foreground py-4">
                No tienes medicamentos activos
              </p>
            )}
          </div>
        </div>

        {/* Recent Exams */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border flex items-center justify-between">
            <h2 className="font-semibold text-lg text-foreground">Examenes recientes</h2>
            <Link href="/afiliado/historial" className="text-primary text-sm font-medium hover:underline flex items-center gap-1">
              Ver historial <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          
          <div className="p-6 space-y-4">
            {[...examenesListos, ...examenesPendientes].slice(0, 3).map((exam) => (
              <div key={exam.id} className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  exam.estado === 'listo' ? 'bg-success/10' : 'bg-warning/10'
                }`}>
                  <FileText className={`w-5 h-5 ${
                    exam.estado === 'listo' ? 'text-success' : 'text-warning'
                  }`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground">{exam.nombre}</p>
                  <p className="text-sm text-muted-foreground">{exam.fecha}</p>
                </div>
                <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                  exam.estado === 'listo' 
                    ? 'bg-success/10 text-success' 
                    : 'bg-warning/10 text-warning'
                }`}>
                  {exam.estado === 'listo' ? 'Disponible' : 'Pendiente'}
                </span>
              </div>
            ))}
            
            {examenesListos.length === 0 && examenesPendientes.length === 0 && (
              <p className="text-center text-muted-foreground py-4">
                No tienes examenes recientes
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
