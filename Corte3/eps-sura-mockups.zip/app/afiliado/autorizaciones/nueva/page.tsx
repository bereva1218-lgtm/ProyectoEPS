'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  ArrowLeft,
  FileText,
  Upload,
  X,
  CheckCircle2,
  AlertCircle
} from 'lucide-react'

type TipoAutorizacion = 'procedimiento' | 'medicamento' | 'examen' | 'hospitalizacion' | 'cirugia'

export default function NuevaAutorizacionPage() {
  const router = useRouter()
  const [tipo, setTipo] = useState<TipoAutorizacion | ''>('')
  const [descripcion, setDescripcion] = useState('')
  const [medicoSolicitante, setMedicoSolicitante] = useState('')
  const [prioridad, setPrioridad] = useState<'normal' | 'urgente'>('normal')
  const [comentarios, setComentarios] = useState('')
  const [archivos, setArchivos] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [error, setError] = useState('')

  const tiposAutorizacion = [
    { value: 'procedimiento', label: 'Procedimiento medico', desc: 'Cirucias menores, terapias, etc.' },
    { value: 'medicamento', label: 'Medicamento especial', desc: 'Medicamentos de alto costo o especializados' },
    { value: 'examen', label: 'Examen diagnostico', desc: 'Resonancias, tomografias, etc.' },
    { value: 'hospitalizacion', label: 'Hospitalizacion', desc: 'Internacion programada' },
    { value: 'cirugia', label: 'Cirugia mayor', desc: 'Intervenciones quirurgicas complejas' },
  ]

  const handleFileUpload = () => {
    // Simulate file upload
    const fileName = `documento_${archivos.length + 1}.pdf`
    setArchivos([...archivos, fileName])
  }

  const removeFile = (index: number) => {
    setArchivos(archivos.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!tipo || !descripcion || !medicoSolicitante) {
      setError('Por favor complete todos los campos obligatorios')
      return
    }

    setIsSubmitting(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    setIsComplete(true)
  }

  if (isComplete) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-card border border-border rounded-2xl p-8 text-center">
          <div className="w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-success" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">Solicitud enviada</h1>
          <p className="text-muted-foreground mb-6">
            Tu solicitud de autorizacion ha sido recibida y sera procesada en un plazo de 24 a 72 horas habiles.
          </p>

          <div className="bg-muted/50 rounded-xl p-4 mb-6 text-left">
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tipo:</span>
                <span className="font-medium text-foreground capitalize">{tipo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Descripcion:</span>
                <span className="font-medium text-foreground">{descripcion}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Prioridad:</span>
                <span className={`font-medium capitalize ${prioridad === 'urgente' ? 'text-destructive' : 'text-foreground'}`}>
                  {prioridad}
                </span>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Link
              href="/afiliado/autorizaciones"
              className="flex-1 px-4 py-2.5 bg-muted text-foreground rounded-xl font-medium hover:bg-muted/80 transition-colors"
            >
              Ver autorizaciones
            </Link>
            <Link
              href="/afiliado"
              className="flex-1 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors"
            >
              Ir al inicio
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => router.push('/afiliado/autorizaciones')}
          className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Nueva solicitud</h1>
          <p className="text-muted-foreground">Complete el formulario para solicitar una autorizacion</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-card border border-border rounded-2xl p-6 space-y-6">
        {error && (
          <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        {/* Tipo de autorizacion */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-3">
            Tipo de autorizacion <span className="text-destructive">*</span>
          </label>
          <div className="grid sm:grid-cols-2 gap-3">
            {tiposAutorizacion.map((t) => (
              <button
                key={t.value}
                type="button"
                onClick={() => setTipo(t.value as TipoAutorizacion)}
                className={`p-4 rounded-xl border text-left transition-colors ${
                  tipo === t.value
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/50'
                }`}
              >
                <p className="font-medium text-foreground">{t.label}</p>
                <p className="text-sm text-muted-foreground mt-1">{t.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Descripcion */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Descripcion del servicio <span className="text-destructive">*</span>
          </label>
          <textarea
            value={descripcion}
            onChange={(e) => setDescripcion(e.target.value)}
            placeholder="Ej: Resonancia magnetica de columna lumbar"
            rows={3}
            className="w-full p-3 bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring resize-none"
          />
        </div>

        {/* Medico solicitante */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Medico solicitante <span className="text-destructive">*</span>
          </label>
          <input
            type="text"
            value={medicoSolicitante}
            onChange={(e) => setMedicoSolicitante(e.target.value)}
            placeholder="Nombre del medico que ordena el servicio"
            className="w-full p-3 bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        {/* Prioridad */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-3">Prioridad</label>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => setPrioridad('normal')}
              className={`flex-1 p-3 rounded-xl border font-medium transition-colors ${
                prioridad === 'normal'
                  ? 'border-primary bg-primary/5 text-primary'
                  : 'border-border text-muted-foreground hover:border-primary/50'
              }`}
            >
              Normal
            </button>
            <button
              type="button"
              onClick={() => setPrioridad('urgente')}
              className={`flex-1 p-3 rounded-xl border font-medium transition-colors ${
                prioridad === 'urgente'
                  ? 'border-destructive bg-destructive/5 text-destructive'
                  : 'border-border text-muted-foreground hover:border-destructive/50'
              }`}
            >
              Urgente
            </button>
          </div>
          {prioridad === 'urgente' && (
            <p className="text-sm text-muted-foreground mt-2">
              Las solicitudes urgentes requieren justificacion medica documentada.
            </p>
          )}
        </div>

        {/* Comentarios adicionales */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Comentarios adicionales (opcional)
          </label>
          <textarea
            value={comentarios}
            onChange={(e) => setComentarios(e.target.value)}
            placeholder="Informacion adicional que considere relevante..."
            rows={3}
            className="w-full p-3 bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring resize-none"
          />
        </div>

        {/* Documentos adjuntos */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-3">
            Documentos de soporte
          </label>
          
          {archivos.length > 0 && (
            <div className="space-y-2 mb-3">
              {archivos.map((archivo, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 bg-muted rounded-lg"
                >
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm text-foreground">{archivo}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeFile(idx)}
                    className="p-1 text-muted-foreground hover:text-destructive rounded"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <button
            type="button"
            onClick={handleFileUpload}
            className="w-full p-4 border-2 border-dashed border-border rounded-xl text-center hover:border-primary/50 hover:bg-muted/50 transition-colors"
          >
            <Upload className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              Haga clic para adjuntar ordenes medicas, formulas u otros documentos
            </p>
          </button>
        </div>

        {/* Info */}
        <div className="bg-muted/50 rounded-xl p-4">
          <p className="text-sm text-muted-foreground">
            <strong className="text-foreground">Importante:</strong> Las solicitudes son revisadas en un plazo de 
            24 a 72 horas habiles para prioridad normal y 24 horas para casos urgentes. 
            Recibira notificacion del resultado por correo electronico.
          </p>
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isSubmitting ? 'Enviando solicitud...' : 'Enviar solicitud'}
        </button>
      </form>
    </div>
  )
}
