"use client"

import { useState } from "react"
import { 
  Building2, 
  Search, 
  MapPin,
  Phone,
  Mail,
  Clock,
  Plus,
  Edit,
  Eye,
  MoreVertical,
  Users,
  Stethoscope,
  CheckCircle,
  XCircle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const ipsList = [
  {
    id: "1",
    name: "IPS Centro Médico Norte",
    type: "Hospital",
    address: "Calle 80 #45-23, Medellín",
    phone: "(604) 123-4567",
    email: "contacto@ipscentronorte.com",
    schedule: "Lun-Sab: 6:00 AM - 10:00 PM",
    status: "activa",
    doctors: 45,
    specialties: ["Medicina General", "Pediatría", "Cardiología", "Ginecología"],
    services: ["Consulta externa", "Urgencias", "Laboratorio", "Imagenología"]
  },
  {
    id: "2",
    name: "Clínica del Sur",
    type: "Clínica",
    address: "Carrera 65 #10-45, Medellín",
    phone: "(604) 234-5678",
    email: "info@clinicadelsur.com",
    schedule: "24 horas",
    status: "activa",
    doctors: 78,
    specialties: ["Medicina General", "Cirugía", "Traumatología", "Neurología"],
    services: ["Consulta externa", "Urgencias", "Cirugía", "UCI"]
  },
  {
    id: "3",
    name: "Centro de Diagnóstico Oriente",
    type: "Centro diagnóstico",
    address: "Avenida Oriental #32-15, Medellín",
    phone: "(604) 345-6789",
    email: "citas@diagnosticooriente.com",
    schedule: "Lun-Vie: 7:00 AM - 6:00 PM",
    status: "activa",
    doctors: 12,
    specialties: ["Radiología", "Ecografía"],
    services: ["Laboratorio", "Imagenología", "Rayos X", "Resonancia"]
  },
  {
    id: "4",
    name: "IPS Salud Integral Occidente",
    type: "IPS",
    address: "Calle 33 #75-100, Medellín",
    phone: "(604) 456-7890",
    email: "contacto@saludintegral.com",
    schedule: "Lun-Vie: 6:00 AM - 8:00 PM",
    status: "inactiva",
    doctors: 25,
    specialties: ["Medicina General", "Odontología", "Psicología"],
    services: ["Consulta externa", "Odontología", "Salud mental"]
  }
]

const typeConfig = {
  Hospital: { color: "bg-primary/10 text-primary border-primary/30" },
  Clínica: { color: "bg-accent/10 text-accent border-accent/30" },
  "Centro diagnóstico": { color: "bg-warning/10 text-warning-foreground border-warning/30" },
  IPS: { color: "bg-success/10 text-success border-success/30" }
}

export default function IPSPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [isNewIPSOpen, setIsNewIPSOpen] = useState(false)
  const [selectedIPS, setSelectedIPS] = useState<typeof ipsList[0] | null>(null)
  const [isDetailOpen, setIsDetailOpen] = useState(false)

  const filteredIPS = ipsList.filter(ips => {
    const matchesSearch = ips.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ips.address.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = typeFilter === "all" || ips.type === typeFilter
    const matchesStatus = statusFilter === "all" || ips.status === statusFilter
    return matchesSearch && matchesType && matchesStatus
  })

  const ipsStats = {
    total: ipsList.length,
    activas: ipsList.filter(i => i.status === "activa").length,
    totalDoctors: ipsList.reduce((acc, ips) => acc + ips.doctors, 0),
    totalSpecialties: new Set(ipsList.flatMap(ips => ips.specialties)).size
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Red de IPS</h1>
          <p className="text-muted-foreground">Gestione las instituciones prestadoras de servicios de salud</p>
        </div>
        <Dialog open={isNewIPSOpen} onOpenChange={setIsNewIPSOpen}>
          <DialogTrigger asChild>
            <Button size="lg">
              <Plus className="h-5 w-5 mr-2" />
              Nueva IPS
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Registrar Nueva IPS</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4 max-h-[60vh] overflow-y-auto">
              <div>
                <Label>Nombre de la IPS</Label>
                <Input placeholder="Nombre completo" className="mt-1" />
              </div>
              <div>
                <Label>Tipo de institución</Label>
                <Select>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Seleccionar tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hospital">Hospital</SelectItem>
                    <SelectItem value="clinica">Clínica</SelectItem>
                    <SelectItem value="centro">Centro diagnóstico</SelectItem>
                    <SelectItem value="ips">IPS</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Dirección</Label>
                <Input placeholder="Dirección completa" className="mt-1" />
              </div>
              <div>
                <Label>Teléfono</Label>
                <Input placeholder="(604) 000-0000" className="mt-1" />
              </div>
              <div>
                <Label>Correo electrónico</Label>
                <Input type="email" placeholder="contacto@ips.com" className="mt-1" />
              </div>
              <div>
                <Label>Horario de atención</Label>
                <Input placeholder="Lun-Vie: 6:00 AM - 8:00 PM" className="mt-1" />
              </div>
              <div>
                <Label>Servicios disponibles</Label>
                <Textarea 
                  placeholder="Liste los servicios separados por coma..."
                  className="mt-1"
                />
              </div>
              <div className="flex gap-2 pt-4">
                <Button variant="outline" className="flex-1" onClick={() => setIsNewIPSOpen(false)}>
                  Cancelar
                </Button>
                <Button className="flex-1" onClick={() => setIsNewIPSOpen(false)}>
                  Registrar IPS
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Building2 className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{ipsStats.total}</p>
                <p className="text-sm text-muted-foreground">Total IPS</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10">
                <CheckCircle className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{ipsStats.activas}</p>
                <p className="text-sm text-muted-foreground">IPS Activas</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/10">
                <Stethoscope className="h-5 w-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{ipsStats.totalDoctors}</p>
                <p className="text-sm text-muted-foreground">Médicos</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-warning/10">
                <Users className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{ipsStats.totalSpecialties}</p>
                <p className="text-sm text-muted-foreground">Especialidades</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nombre o dirección..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los tipos</SelectItem>
                <SelectItem value="Hospital">Hospital</SelectItem>
                <SelectItem value="Clínica">Clínica</SelectItem>
                <SelectItem value="Centro diagnóstico">Centro diagnóstico</SelectItem>
                <SelectItem value="IPS">IPS</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="Estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="activa">Activas</SelectItem>
                <SelectItem value="inactiva">Inactivas</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* IPS Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredIPS.map((ips) => {
          const typeInfo = typeConfig[ips.type as keyof typeof typeConfig]

          return (
            <Card key={ips.id} className={`hover:shadow-md transition-shadow ${
              ips.status === "inactiva" ? "opacity-70" : ""
            }`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className="p-3 rounded-xl bg-primary/10">
                      <Building2 className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{ips.name}</CardTitle>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className={typeInfo.color}>
                          {ips.type}
                        </Badge>
                        <Badge 
                          variant="outline" 
                          className={ips.status === "activa" 
                            ? "bg-success/10 text-success border-success/30"
                            : "bg-muted text-muted-foreground"
                          }
                        >
                          {ips.status === "activa" ? (
                            <><CheckCircle className="h-3 w-3 mr-1" /> Activa</>
                          ) : (
                            <><XCircle className="h-3 w-3 mr-1" /> Inactiva</>
                          )}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => {
                        setSelectedIPS(ips)
                        setIsDetailOpen(true)
                      }}>
                        <Eye className="h-4 w-4 mr-2" />
                        Ver detalles
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Edit className="h-4 w-4 mr-2" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      {ips.status === "activa" ? (
                        <DropdownMenuItem className="text-destructive">
                          <XCircle className="h-4 w-4 mr-2" />
                          Desactivar
                        </DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem className="text-success">
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Activar
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <span>{ips.address}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{ips.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>{ips.schedule}</span>
                  </div>
                </div>

                <div className="pt-3 border-t">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Médicos:</span>
                    <span className="font-medium">{ips.doctors}</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {ips.specialties.slice(0, 3).map((specialty, i) => (
                      <Badge key={i} variant="secondary" className="text-xs">
                        {specialty}
                      </Badge>
                    ))}
                    {ips.specialties.length > 3 && (
                      <Badge variant="secondary" className="text-xs">
                        +{ips.specialties.length - 3}
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => {
                      setSelectedIPS(ips)
                      setIsDetailOpen(true)
                    }}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    Ver detalles
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Stethoscope className="h-4 w-4 mr-1" />
                    Ver médicos
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {filteredIPS.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-lg font-medium text-muted-foreground">No se encontraron IPS</p>
            <p className="text-sm text-muted-foreground">Intente ajustar los filtros de búsqueda</p>
          </CardContent>
        </Card>
      )}

      {/* Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedIPS?.name}</DialogTitle>
          </DialogHeader>
          {selectedIPS && (
            <div className="space-y-6 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">Tipo</Label>
                  <p className="font-medium">{selectedIPS.type}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Estado</Label>
                  <p className="font-medium capitalize">{selectedIPS.status}</p>
                </div>
                <div className="col-span-2">
                  <Label className="text-muted-foreground">Dirección</Label>
                  <p className="font-medium">{selectedIPS.address}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Teléfono</Label>
                  <p className="font-medium">{selectedIPS.phone}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Email</Label>
                  <p className="font-medium">{selectedIPS.email}</p>
                </div>
                <div className="col-span-2">
                  <Label className="text-muted-foreground">Horario</Label>
                  <p className="font-medium">{selectedIPS.schedule}</p>
                </div>
              </div>

              <div>
                <Label className="text-muted-foreground">Especialidades</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedIPS.specialties.map((specialty, i) => (
                    <Badge key={i} variant="secondary">{specialty}</Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-muted-foreground">Servicios</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedIPS.services.map((service, i) => (
                    <Badge key={i} variant="outline">{service}</Badge>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <Button variant="outline" className="flex-1" onClick={() => setIsDetailOpen(false)}>
                  Cerrar
                </Button>
                <Button className="flex-1">
                  <Edit className="h-4 w-4 mr-2" />
                  Editar IPS
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
