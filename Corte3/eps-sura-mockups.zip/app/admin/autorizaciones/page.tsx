"use client"

import { useState } from "react"
import { 
  FileCheck, 
  Search, 
  Filter,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Eye,
  Calendar,
  User,
  Stethoscope,
  FileText
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"

const authorizations = [
  {
    id: "AUT-2024-1234",
    patient: "María García López",
    patientId: "1.234.567.890",
    doctor: "Dr. Carlos Mendoza",
    type: "Cirugía ambulatoria",
    description: "Colecistectomía laparoscópica",
    requestDate: "2024-02-15",
    status: "pendiente",
    priority: "alta",
    documents: ["Orden médica", "Exámenes prequirúrgicos"]
  },
  {
    id: "AUT-2024-1235",
    patient: "Carlos Martínez Ruiz",
    patientId: "9.876.543.210",
    doctor: "Dra. Ana López",
    type: "Imagenología",
    description: "Resonancia magnética cerebral con contraste",
    requestDate: "2024-02-15",
    status: "pendiente",
    priority: "urgente",
    documents: ["Orden médica", "Historia clínica"]
  },
  {
    id: "AUT-2024-1236",
    patient: "Ana Rodríguez Pérez",
    patientId: "5.555.666.777",
    doctor: "Dr. Roberto García",
    type: "Medicamento especial",
    description: "Adalimumab 40mg - Tratamiento para artritis reumatoide",
    requestDate: "2024-02-14",
    status: "aprobada",
    priority: "alta",
    documents: ["Orden médica", "Diagnóstico confirmado"]
  },
  {
    id: "AUT-2024-1237",
    patient: "Pedro Sánchez Gómez",
    patientId: "1.111.222.333",
    doctor: "Dra. María Sánchez",
    type: "Procedimiento",
    description: "Artroscopia de rodilla",
    requestDate: "2024-02-13",
    status: "rechazada",
    priority: "normal",
    documents: ["Orden médica"],
    rejectionReason: "Documentación incompleta - Falta resultado de radiografía"
  },
  {
    id: "AUT-2024-1238",
    patient: "Laura Gómez Torres",
    patientId: "4.444.555.666",
    doctor: "Dr. Carlos Mendoza",
    type: "Interconsulta",
    description: "Valoración por neurología",
    requestDate: "2024-02-13",
    status: "en_revision",
    priority: "normal",
    documents: ["Orden médica", "Historia clínica"]
  }
]

const statusConfig = {
  pendiente: { label: "Pendiente", color: "bg-warning/10 text-warning-foreground border-warning/30", icon: Clock },
  en_revision: { label: "En revisión", color: "bg-primary/10 text-primary border-primary/30", icon: FileText },
  aprobada: { label: "Aprobada", color: "bg-success/10 text-success border-success/30", icon: CheckCircle },
  rechazada: { label: "Rechazada", color: "bg-destructive/10 text-destructive border-destructive/30", icon: XCircle }
}

const priorityConfig = {
  normal: { label: "Normal", color: "bg-muted text-muted-foreground" },
  alta: { label: "Alta", color: "bg-warning/20 text-warning-foreground" },
  urgente: { label: "Urgente", color: "bg-destructive/20 text-destructive" }
}

export default function AutorizacionesAdminPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [activeTab, setActiveTab] = useState("pendiente")
  const [selectedAuth, setSelectedAuth] = useState<typeof authorizations[0] | null>(null)
  const [isDetailOpen, setIsDetailOpen] = useState(false)
  const [decision, setDecision] = useState("")
  const [comments, setComments] = useState("")

  const filteredAuths = authorizations.filter(auth => {
    const matchesSearch = auth.patient.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         auth.id.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || auth.status === statusFilter
    const matchesPriority = priorityFilter === "all" || auth.priority === priorityFilter
    const matchesTab = activeTab === "all" || auth.status === activeTab
    return matchesSearch && matchesStatus && matchesPriority && matchesTab
  })

  const authStats = {
    total: authorizations.length,
    pendientes: authorizations.filter(a => a.status === "pendiente").length,
    enRevision: authorizations.filter(a => a.status === "en_revision").length,
    aprobadas: authorizations.filter(a => a.status === "aprobada").length,
    rechazadas: authorizations.filter(a => a.status === "rechazada").length
  }

  const handleViewDetails = (auth: typeof authorizations[0]) => {
    setSelectedAuth(auth)
    setIsDetailOpen(true)
    setDecision("")
    setComments("")
  }

  const handleDecision = () => {
    alert(`Autorización ${selectedAuth?.id} - Decisión: ${decision}`)
    setIsDetailOpen(false)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Gestión de Autorizaciones</h1>
        <p className="text-muted-foreground">Revise y procese las solicitudes de autorización médica</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <FileCheck className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{authStats.total}</p>
                <p className="text-sm text-muted-foreground">Total</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-warning/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-warning/10">
                <Clock className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{authStats.pendientes}</p>
                <p className="text-sm text-muted-foreground">Pendientes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{authStats.enRevision}</p>
                <p className="text-sm text-muted-foreground">En revisión</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10">
                <CheckCircle className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{authStats.aprobadas}</p>
                <p className="text-sm text-muted-foreground">Aprobadas</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-destructive/10">
                <XCircle className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold">{authStats.rechazadas}</p>
                <p className="text-sm text-muted-foreground">Rechazadas</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs and Filters */}
      <Card>
        <CardContent className="p-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
              <TabsList>
                <TabsTrigger value="pendiente">
                  Pendientes
                  <Badge variant="secondary" className="ml-2 bg-warning/20">{authStats.pendientes}</Badge>
                </TabsTrigger>
                <TabsTrigger value="en_revision">En revisión</TabsTrigger>
                <TabsTrigger value="aprobada">Aprobadas</TabsTrigger>
                <TabsTrigger value="rechazada">Rechazadas</TabsTrigger>
                <TabsTrigger value="all">Todas</TabsTrigger>
              </TabsList>
              <div className="flex gap-2">
                <div className="relative flex-1 md:w-[250px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar..."
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-[140px]">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Prioridad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    <SelectItem value="urgente">Urgente</SelectItem>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <TabsContent value={activeTab} className="m-0">
              <div className="space-y-3">
                {filteredAuths.map((auth) => {
                  const statusInfo = statusConfig[auth.status as keyof typeof statusConfig]
                  const priorityInfo = priorityConfig[auth.priority as keyof typeof priorityConfig]
                  const StatusIcon = statusInfo.icon

                  return (
                    <div 
                      key={auth.id}
                      className={`p-4 rounded-lg border transition-colors ${
                        auth.priority === "urgente" 
                          ? "bg-destructive/5 border-destructive/20 hover:bg-destructive/10" 
                          : "bg-muted/30 hover:bg-muted/50"
                      }`}
                    >
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex flex-wrap items-center gap-2 mb-2">
                            <span className="font-mono text-sm font-medium text-primary">{auth.id}</span>
                            <Badge variant="outline" className={statusInfo.color}>
                              <StatusIcon className="h-3 w-3 mr-1" />
                              {statusInfo.label}
                            </Badge>
                            <Badge variant="secondary" className={priorityInfo.color}>
                              {auth.priority === "urgente" && <AlertTriangle className="h-3 w-3 mr-1" />}
                              {priorityInfo.label}
                            </Badge>
                            <Badge variant="outline">{auth.type}</Badge>
                          </div>
                          <div className="flex items-center gap-2 mb-1">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{auth.patient}</span>
                            <span className="text-sm text-muted-foreground">CC: {auth.patientId}</span>
                          </div>
                          <div className="flex items-center gap-2 mb-2 text-sm text-muted-foreground">
                            <Stethoscope className="h-4 w-4" />
                            <span>{auth.doctor}</span>
                          </div>
                          <p className="text-sm">{auth.description}</p>
                          <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              {auth.requestDate}
                            </span>
                            <span className="flex items-center gap-1">
                              <FileText className="h-4 w-4" />
                              {auth.documents.length} documentos
                            </span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={() => handleViewDetails(auth)}>
                            <Eye className="h-4 w-4 mr-1" />
                            Ver detalles
                          </Button>
                          {(auth.status === "pendiente" || auth.status === "en_revision") && (
                            <>
                              <Button size="sm" variant="outline" className="text-destructive border-destructive/30 hover:bg-destructive/10">
                                <XCircle className="h-4 w-4 mr-1" />
                                Rechazar
                              </Button>
                              <Button size="sm">
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Aprobar
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {filteredAuths.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <FileCheck className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-lg font-medium text-muted-foreground">No se encontraron autorizaciones</p>
            <p className="text-sm text-muted-foreground">Intente ajustar los filtros de búsqueda</p>
          </CardContent>
        </Card>
      )}

      {/* Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalle de Autorización {selectedAuth?.id}</DialogTitle>
          </DialogHeader>
          {selectedAuth && (
            <div className="space-y-6 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">Paciente</Label>
                  <p className="font-medium">{selectedAuth.patient}</p>
                  <p className="text-sm text-muted-foreground">CC: {selectedAuth.patientId}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Médico solicitante</Label>
                  <p className="font-medium">{selectedAuth.doctor}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Tipo de servicio</Label>
                  <p className="font-medium">{selectedAuth.type}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Fecha de solicitud</Label>
                  <p className="font-medium">{selectedAuth.requestDate}</p>
                </div>
              </div>

              <div>
                <Label className="text-muted-foreground">Descripción</Label>
                <p className="font-medium">{selectedAuth.description}</p>
              </div>

              <div>
                <Label className="text-muted-foreground">Documentos adjuntos</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedAuth.documents.map((doc, i) => (
                    <Badge key={i} variant="secondary" className="cursor-pointer hover:bg-primary/10">
                      <FileText className="h-3 w-3 mr-1" />
                      {doc}
                    </Badge>
                  ))}
                </div>
              </div>

              {(selectedAuth.status === "pendiente" || selectedAuth.status === "en_revision") && (
                <>
                  <div>
                    <Label>Decisión</Label>
                    <Select value={decision} onValueChange={setDecision}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Seleccionar decisión" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="aprobar">Aprobar</SelectItem>
                        <SelectItem value="rechazar">Rechazar</SelectItem>
                        <SelectItem value="solicitar_documentos">Solicitar más documentos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Comentarios / Motivo</Label>
                    <Textarea
                      placeholder="Ingrese comentarios o el motivo de la decisión..."
                      className="mt-1 min-h-[100px]"
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                    />
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button variant="outline" className="flex-1" onClick={() => setIsDetailOpen(false)}>
                      Cancelar
                    </Button>
                    <Button className="flex-1" onClick={handleDecision} disabled={!decision}>
                      Confirmar Decisión
                    </Button>
                  </div>
                </>
              )}

              {selectedAuth.status === "rechazada" && selectedAuth.rejectionReason && (
                <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
                  <Label className="text-destructive">Motivo del rechazo</Label>
                  <p className="text-sm mt-1">{selectedAuth.rejectionReason}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
