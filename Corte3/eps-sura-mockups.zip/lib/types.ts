export type UserRole = 'afiliado' | 'medico' | 'admin'

export interface User {
  id: string
  nombre: string
  apellido: string
  email: string
  documento: string
  tipoDocumento: 'CC' | 'CE' | 'TI' | 'PA'
  telefono: string
  direccion: string
  ciudad: string
  fechaNacimiento: string
  genero: 'M' | 'F' | 'O'
  rol: UserRole
  avatar?: string
  // Campos especificos de afiliado
  tipoAfiliacion?: 'cotizante' | 'beneficiario'
  planSalud?: string
  grupoFamiliar?: string[]
  // Campos especificos de medico
  especialidad?: string
  registroMedico?: string
  consultorio?: string
}

export interface Cita {
  id: string
  pacienteId: string
  pacienteNombre: string
  medicoId: string
  medicoNombre: string
  especialidad: string
  fecha: string
  hora: string
  estado: 'programada' | 'confirmada' | 'en_curso' | 'completada' | 'cancelada' | 'no_asistio'
  tipo: 'presencial' | 'virtual'
  consultorio?: string
  motivo?: string
  notas?: string
}

export interface Autorizacion {
  id: string
  pacienteId: string
  pacienteNombre: string
  tipo: 'procedimiento' | 'medicamento' | 'examen' | 'hospitalizacion' | 'cirugia'
  descripcion: string
  medicoSolicitante: string
  fechaSolicitud: string
  fechaRespuesta?: string
  estado: 'pendiente' | 'aprobada' | 'rechazada' | 'en_revision'
  prioridad: 'normal' | 'urgente'
  documentos?: string[]
  comentarios?: string
}

export interface Medicamento {
  id: string
  nombre: string
  principioActivo: string
  presentacion: string
  dosis: string
  frecuencia: string
  duracion: string
  fechaInicio: string
  fechaFin: string
  medicoId: string
  medicoNombre: string
  estado: 'activo' | 'completado' | 'suspendido'
  instrucciones?: string
  reclamosPendientes?: number
}

export interface HistorialMedico {
  id: string
  pacienteId: string
  fecha: string
  tipo: 'consulta' | 'examen' | 'procedimiento' | 'hospitalizacion'
  medicoNombre: string
  especialidad: string
  diagnostico: string
  descripcion: string
  resultados?: string
  adjuntos?: string[]
}

export interface ResultadoExamen {
  id: string
  pacienteId: string
  nombre: string
  tipo: 'laboratorio' | 'imagenologia' | 'otro'
  fecha: string
  estado: 'pendiente' | 'listo'
  resultadoUrl?: string
  medicoSolicitante: string
}

export interface Notificacion {
  id: string
  usuarioId: string
  titulo: string
  mensaje: string
  tipo: 'cita' | 'autorizacion' | 'medicamento' | 'general'
  fecha: string
  leida: boolean
  accionUrl?: string
}
