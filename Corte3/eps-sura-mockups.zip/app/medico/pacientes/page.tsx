'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { citas, historialMedico, usuarios } from '@/lib/mock-data'
import {
  Search,
  User,
  Calendar,
  FileText,
  ChevronRight,
  Phone,
  Mail,
  MapPin,
  Clock,
  Activity,
  Pill,
  X
} from 'lucide-react'

export default function PacientesMedicoPage() {
  const { user } = useAuth()
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedPaciente, setSelectedPaciente] = useState<typeof usuarios[0] | null>(null)

  // Get unique patients from appointments
  const medicoCitas = citas.filter(c => c.medicoId === user?.id)
  const pacienteIds = [...new Set(medicoCitas.map(c => c.pacienteId))]
  const pacientes = usuarios.filter(u => pacienteIds.includes(u.id))

  const filteredPacientes = pacientes.filter(p =>
    `${p.nombre} ${p.apellido}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.documento.includes(searchQuery)
  )

  const getPacienteCitas = (pacienteId: string) => {
    return citas.filter(c => c.pacienteId === pacienteId && c.medicoId === user?.id)
  }

  const getPacienteHistorial = (pacienteId: string) => {
    return historialMedico.filter(h => h.pacienteId === pacienteId)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Mis Pacientes</h1>
        <p className="text-muted-foreground mt-1">Consulta el historial y seguimiento de tus pacientes</p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          placeholder="Buscar por nombre o documento..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-3 bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Patients List */}
        <div className="lg:col-span-1 space-y-3">
          <p className="text-sm text-muted-foreground">
            {filteredPacientes.length} paciente(s) encontrado(s)
          </p>
          
          {filteredPacientes.map((paciente) => {
            const citasCount = getPacienteCitas(paciente.id).length
            const ultimaCita = getPacienteCitas(paciente.id)
              .sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())[0]

            return (
              <button
                key={paciente.id}
                onClick={() => setSelectedPaciente(paciente)}
                className={`w-full flex items-center gap-4 p-4 rounded-xl border text-left transition-colors ${
                  selectedPaciente?.id === paciente.id
                    ? 'border-primary bg-primary/5'
                    : 'border-border bg-card hover:border-primary/50'
                }`}
              >
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <User className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground truncate">
                    {paciente.nombre} {paciente.apellido}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {paciente.tipoDocumento} {paciente.documento}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {citasCount} consulta(s) - Ultima: {ultimaCita?.fecha || 'N/A'}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
              </button>
            )
          })}

          {filteredPacientes.length === 0 && (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground">
                {searchQuery ? 'No se encontraron pacientes' : 'No tiene pacientes registrados'}
              </p>
            </div>
          )}
        </div>

        {/* Patient Details */}
        <div className="lg:col-span-2 bg-card border border-border rounded-2xl overflow-hidden">
          {selectedPaciente ? (
            <>
              {/* Patient Header */}
              <div className="p-6 border-b border-border">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center">
                      <User className="w-8 h-8 text-primary" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-foreground">
                        {selectedPaciente.nombre} {selectedPaciente.apellido}
                      </h2>
                      <p className="text-muted-foreground">
                        {selectedPaciente.tipoDocumento} {selectedPaciente.documento}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedPaciente(null)}
                    className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg lg:hidden"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Contact Info */}
                <div className="grid sm:grid-cols-3 gap-4 mt-6">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone className="w-4 h-4" />
                    {selectedPaciente.telefono}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Mail className="w-4 h-4" />
                    {selectedPaciente.email}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    {selectedPaciente.ciudad}
                  </div>
                </div>
              </div>

              {/* Tabs Content */}
              <div className="p-6">
                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="bg-muted/50 rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-foreground">
                      {getPacienteCitas(selectedPaciente.id).length}
                    </p>
                    <p className="text-sm text-muted-foreground">Consultas</p>
                  </div>
                  <div className="bg-muted/50 rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-foreground">
                      {getPacienteHistorial(selectedPaciente.id).length}
                    </p>
                    <p className="text-sm text-muted-foreground">Registros</p>
                  </div>
                  <div className="bg-muted/50 rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-foreground">
                      {new Date().getFullYear() - new Date(selectedPaciente.fechaNacimiento).getFullYear()}
                    </p>
                    <p className="text-sm text-muted-foreground">Anos</p>
                  </div>
                </div>

                {/* Recent Appointments */}
                <div className="mb-6">
                  <h3 className="font-semibold text-foreground mb-3">Consultas recientes</h3>
                  <div className="space-y-2">
                    {getPacienteCitas(selectedPaciente.id).slice(0, 3).map((cita) => (
                      <div
                        key={cita.id}
                        className="flex items-center gap-4 p-3 bg-muted/50 rounded-xl"
                      >
                        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                          <Calendar className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-foreground">{cita.fecha}</p>
                          <p className="text-sm text-muted-foreground">{cita.motivo}</p>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-xs font-medium capitalize ${
                          cita.estado === 'completada' 
                            ? 'bg-success/10 text-success' 
                            : cita.estado === 'confirmada'
                              ? 'bg-warning/10 text-warning'
                              : 'bg-muted text-muted-foreground'
                        }`}>
                          {cita.estado}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Medical History */}
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Historial medico</h3>
                  <div className="space-y-2">
                    {getPacienteHistorial(selectedPaciente.id).slice(0, 3).map((hist) => (
                      <div
                        key={hist.id}
                        className="flex items-start gap-4 p-3 bg-muted/50 rounded-xl"
                      >
                        <div className="w-10 h-10 bg-chart-2/10 rounded-lg flex items-center justify-center">
                          <Activity className="w-5 h-5 text-chart-2" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-foreground">{hist.diagnostico}</p>
                          <p className="text-sm text-muted-foreground">{hist.fecha} - {hist.especialidad}</p>
                        </div>
                      </div>
                    ))}

                    {getPacienteHistorial(selectedPaciente.id).length === 0 && (
                      <p className="text-center text-muted-foreground py-4">
                        No hay registros en el historial
                      </p>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-3 mt-6 pt-6 border-t border-border">
                  <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors">
                    <FileText className="w-4 h-4" />
                    Ver historial completo
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg font-medium hover:bg-muted/80 transition-colors">
                    <Pill className="w-4 h-4" />
                    Nueva formula
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="p-6 text-center py-20">
              <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-lg text-foreground mb-2">
                Selecciona un paciente
              </h3>
              <p className="text-muted-foreground">
                Haz clic en un paciente de la lista para ver sus detalles
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
