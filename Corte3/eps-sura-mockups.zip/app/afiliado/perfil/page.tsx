'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  CreditCard,
  Shield,
  Edit2,
  Check,
  X,
  Camera,
  Users
} from 'lucide-react'

export default function PerfilPage() {
  const { user } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    telefono: user?.telefono || '',
    direccion: user?.direccion || '',
    ciudad: user?.ciudad || '',
  })

  const handleSave = () => {
    // In production, this would call an API
    setIsEditing(false)
  }

  const handleCancel = () => {
    setFormData({
      telefono: user?.telefono || '',
      direccion: user?.direccion || '',
      ciudad: user?.ciudad || '',
    })
    setIsEditing(false)
  }

  const formatDate = (dateString: string | undefined) => {
    if (!dateString) return '-'
    const date = new Date(dateString)
    return date.toLocaleDateString('es-CO', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  }

  const calculateAge = (dateString: string | undefined) => {
    if (!dateString) return '-'
    const today = new Date()
    const birth = new Date(dateString)
    let age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--
    }
    return `${age} anos`
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Mi Perfil</h1>
        <p className="text-muted-foreground mt-1">Gestiona tu informacion personal y de afiliacion</p>
      </div>

      {/* Profile Card */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        {/* Cover & Avatar */}
        <div className="h-32 bg-gradient-to-r from-primary to-primary/70 relative">
          <div className="absolute -bottom-12 left-6">
            <div className="relative">
              <div className="w-24 h-24 bg-card rounded-2xl border-4 border-card flex items-center justify-center shadow-lg">
                <User className="w-12 h-12 text-primary" />
              </div>
              <button className="absolute bottom-0 right-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground shadow-lg hover:bg-primary/90 transition-colors">
                <Camera className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* User Info */}
        <div className="pt-16 pb-6 px-6">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-xl font-bold text-foreground">
                {user?.nombre} {user?.apellido}
              </h2>
              <p className="text-muted-foreground">{user?.email}</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium">
                {user?.planSalud}
              </span>
              <span className="px-3 py-1 bg-muted text-muted-foreground rounded-full text-sm font-medium capitalize">
                {user?.tipoAfiliacion}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Personal Information */}
      <div className="bg-card border border-border rounded-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-semibold text-lg text-foreground">Informacion personal</h3>
          {!isEditing ? (
            <button
              onClick={() => setIsEditing(true)}
              className="flex items-center gap-2 text-primary text-sm font-medium hover:underline"
            >
              <Edit2 className="w-4 h-4" />
              Editar
            </button>
          ) : (
            <div className="flex gap-2">
              <button
                onClick={handleCancel}
                className="flex items-center gap-1 px-3 py-1.5 text-muted-foreground text-sm font-medium hover:bg-muted rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
                Cancelar
              </button>
              <button
                onClick={handleSave}
                className="flex items-center gap-1 px-3 py-1.5 bg-primary text-primary-foreground text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors"
              >
                <Check className="w-4 h-4" />
                Guardar
              </button>
            </div>
          )}
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <CreditCard className="w-4 h-4" />
              Documento
            </div>
            <p className="font-medium text-foreground">
              {user?.tipoDocumento} {user?.documento}
            </p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <Mail className="w-4 h-4" />
              Correo electronico
            </div>
            <p className="font-medium text-foreground">{user?.email}</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <Phone className="w-4 h-4" />
              Telefono
            </div>
            {isEditing ? (
              <input
                type="tel"
                value={formData.telefono}
                onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                className="w-full p-2 bg-muted border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
              />
            ) : (
              <p className="font-medium text-foreground">{user?.telefono}</p>
            )}
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <Calendar className="w-4 h-4" />
              Fecha de nacimiento
            </div>
            <p className="font-medium text-foreground">
              {formatDate(user?.fechaNacimiento)} ({calculateAge(user?.fechaNacimiento)})
            </p>
          </div>

          <div className="space-y-1 sm:col-span-2">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <MapPin className="w-4 h-4" />
              Direccion
            </div>
            {isEditing ? (
              <div className="grid sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  value={formData.direccion}
                  onChange={(e) => setFormData({ ...formData, direccion: e.target.value })}
                  placeholder="Direccion"
                  className="w-full p-2 bg-muted border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                />
                <input
                  type="text"
                  value={formData.ciudad}
                  onChange={(e) => setFormData({ ...formData, ciudad: e.target.value })}
                  placeholder="Ciudad"
                  className="w-full p-2 bg-muted border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
            ) : (
              <p className="font-medium text-foreground">
                {user?.direccion}, {user?.ciudad}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Affiliation Info */}
      <div className="bg-card border border-border rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-6">
          <Shield className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-lg text-foreground">Informacion de afiliacion</h3>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Tipo de afiliacion</p>
            <p className="font-medium text-foreground capitalize">{user?.tipoAfiliacion}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Plan de salud</p>
            <p className="font-medium text-foreground">{user?.planSalud}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Estado</p>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-success/10 text-success rounded-full text-sm font-medium">
              <span className="w-2 h-2 bg-success rounded-full" />
              Activo
            </span>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Numero de afiliado</p>
            <p className="font-medium text-foreground">AF-{user?.documento?.slice(-6)}</p>
          </div>
        </div>
      </div>

      {/* Family Group */}
      {user?.grupoFamiliar && user.grupoFamiliar.length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <Users className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-lg text-foreground">Grupo familiar</h3>
          </div>

          <div className="space-y-3">
            {user.grupoFamiliar.map((memberId, idx) => (
              <div key={memberId} className="flex items-center gap-4 p-4 bg-muted/50 rounded-xl">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-foreground">Beneficiario {idx + 1}</p>
                  <p className="text-sm text-muted-foreground">ID: {memberId}</p>
                </div>
                <span className="px-2.5 py-1 bg-muted text-muted-foreground rounded-full text-xs font-medium">
                  Beneficiario
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Security */}
      <div className="bg-card border border-border rounded-2xl p-6">
        <h3 className="font-semibold text-lg text-foreground mb-6">Seguridad</h3>
        
        <div className="space-y-4">
          <button className="w-full flex items-center justify-between p-4 bg-muted/50 hover:bg-muted rounded-xl transition-colors text-left">
            <div>
              <p className="font-medium text-foreground">Cambiar contrasena</p>
              <p className="text-sm text-muted-foreground">Actualiza tu contrasena de acceso</p>
            </div>
            <Edit2 className="w-5 h-5 text-muted-foreground" />
          </button>
          
          <button className="w-full flex items-center justify-between p-4 bg-muted/50 hover:bg-muted rounded-xl transition-colors text-left">
            <div>
              <p className="font-medium text-foreground">Verificacion en dos pasos</p>
              <p className="text-sm text-muted-foreground">Agrega una capa extra de seguridad</p>
            </div>
            <span className="px-2.5 py-1 bg-warning/10 text-warning rounded-full text-xs font-medium">
              No activado
            </span>
          </button>
        </div>
      </div>
    </div>
  )
}
