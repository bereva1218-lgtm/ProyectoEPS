'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { historialMedico, resultadosExamenes } from '@/lib/mock-data'
import {
  FileText,
  Download,
  Search,
  Filter,
  Calendar,
  User,
  Stethoscope,
  TestTube,
  Activity,
  Building2,
  ChevronDown,
  ChevronUp,
  ExternalLink
} from 'lucide-react'

export default function HistorialPage() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState<'historial' | 'examenes'>('historial')
  const [expandedItems, setExpandedItems] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState('')

  const userHistorial = historialMedico.filter(h => h.pacienteId === user?.id)
  const userExamenes = resultadosExamenes.filter(e => e.pacienteId === user?.id)

  const filteredHistorial = userHistorial.filter(h =>
    h.diagnostico.toLowerCase().includes(searchQuery.toLowerCase()) ||
    h.medicoNombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
    h.especialidad.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const toggleExpand = (id: string) => {
    setExpandedItems(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  const getTypeIcon = (tipo: string) => {
    switch (tipo) {
      case 'consulta': return Stethoscope
      case 'examen': return TestTube
      case 'procedimiento': return Activity
      case 'hospitalizacion': return Building2
      default: return FileText
    }
  }

  const getTypeColor = (tipo: string) => {
    switch (tipo) {
      case 'consulta': return 'bg-chart-1/10 text-chart-1'
      case 'examen': return 'bg-chart-2/10 text-chart-2'
      case 'procedimiento': return 'bg-chart-3/10 text-chart-3'
      case 'hospitalizacion': return 'bg-chart-4/10 text-chart-4'
      default: return 'bg-muted text-muted-foreground'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Historial Medico</h1>
        <p className="text-muted-foreground mt-1">Consulta tu historia clinica y resultados de examenes</p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border">
        <button
          onClick={() => setActiveTab('historial')}
          className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
            activeTab === 'historial'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          Historia clinica
        </button>
        <button
          onClick={() => setActiveTab('examenes')}
          className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
            activeTab === 'examenes'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          Resultados de examenes
          {userExamenes.filter(e => e.estado === 'listo').length > 0 && (
            <span className="ml-2 px-2 py-0.5 bg-success/10 text-success text-xs rounded-full">
              {userExamenes.filter(e => e.estado === 'listo').length} nuevo(s)
            </span>
          )}
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          placeholder={activeTab === 'historial' ? 'Buscar en historial...' : 'Buscar examenes...'}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-3 bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      {/* Historial Tab */}
      {activeTab === 'historial' && (
        <div className="space-y-4">
          {filteredHistorial.length > 0 ? (
            filteredHistorial.map((item) => {
              const Icon = getTypeIcon(item.tipo)
              const isExpanded = expandedItems.includes(item.id)

              return (
                <div
                  key={item.id}
                  className="bg-card border border-border rounded-2xl overflow-hidden"
                >
                  <button
                    onClick={() => toggleExpand(item.id)}
                    className="w-full p-5 flex items-start gap-4 text-left hover:bg-muted/50 transition-colors"
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${getTypeColor(item.tipo)}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <p className="font-semibold text-foreground">{item.diagnostico}</p>
                          <p className="text-sm text-muted-foreground mt-1">{item.medicoNombre} - {item.especialidad}</p>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className="text-sm text-muted-foreground">{item.fecha}</span>
                          {isExpanded ? (
                            <ChevronUp className="w-5 h-5 text-muted-foreground" />
                          ) : (
                            <ChevronDown className="w-5 h-5 text-muted-foreground" />
                          )}
                        </div>
                      </div>
                      
                      <div className="mt-2">
                        <span className={`px-2 py-0.5 rounded text-xs font-medium capitalize ${getTypeColor(item.tipo)}`}>
                          {item.tipo}
                        </span>
                      </div>
                    </div>
                  </button>

                  {isExpanded && (
                    <div className="px-5 pb-5 pt-0 border-t border-border mt-0">
                      <div className="pt-4 space-y-4">
                        <div>
                          <p className="text-sm font-medium text-foreground mb-1">Descripcion</p>
                          <p className="text-sm text-muted-foreground">{item.descripcion}</p>
                        </div>

                        {item.resultados && (
                          <div>
                            <p className="text-sm font-medium text-foreground mb-1">Resultados</p>
                            <p className="text-sm text-muted-foreground">{item.resultados}</p>
                          </div>
                        )}

                        {item.adjuntos && item.adjuntos.length > 0 && (
                          <div>
                            <p className="text-sm font-medium text-foreground mb-2">Documentos adjuntos</p>
                            <div className="flex flex-wrap gap-2">
                              {item.adjuntos.map((adj, idx) => (
                                <button
                                  key={idx}
                                  className="flex items-center gap-2 px-3 py-2 bg-muted rounded-lg text-sm text-foreground hover:bg-muted/80 transition-colors"
                                >
                                  <FileText className="w-4 h-4" />
                                  {adj}
                                  <Download className="w-4 h-4 text-muted-foreground" />
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )
            })
          ) : (
            <div className="bg-card border border-border rounded-2xl p-12 text-center">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-lg text-foreground mb-2">No hay registros</h3>
              <p className="text-muted-foreground">
                {searchQuery ? 'No se encontraron resultados para tu busqueda' : 'No tienes registros en tu historial medico'}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Examenes Tab */}
      {activeTab === 'examenes' && (
        <div className="space-y-4">
          {/* Examenes Listos */}
          {userExamenes.filter(e => e.estado === 'listo').length > 0 && (
            <div className="space-y-3">
              <h2 className="font-semibold text-foreground">Resultados disponibles</h2>
              {userExamenes
                .filter(e => e.estado === 'listo')
                .map((exam) => (
                  <div
                    key={exam.id}
                    className="bg-card border border-success/30 rounded-xl p-4 flex items-center gap-4"
                  >
                    <div className="w-12 h-12 bg-success/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <TestTube className="w-6 h-6 text-success" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground">{exam.nombre}</p>
                      <p className="text-sm text-muted-foreground">
                        {exam.fecha} - {exam.medicoSolicitante}
                      </p>
                    </div>
                    <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                      <Download className="w-4 h-4" />
                      Descargar
                    </button>
                  </div>
                ))}
            </div>
          )}

          {/* Examenes Pendientes */}
          {userExamenes.filter(e => e.estado === 'pendiente').length > 0 && (
            <div className="space-y-3">
              <h2 className="font-semibold text-foreground">Pendientes</h2>
              {userExamenes
                .filter(e => e.estado === 'pendiente')
                .map((exam) => (
                  <div
                    key={exam.id}
                    className="bg-card border border-border rounded-xl p-4 flex items-center gap-4"
                  >
                    <div className="w-12 h-12 bg-warning/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <TestTube className="w-6 h-6 text-warning" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground">{exam.nombre}</p>
                      <p className="text-sm text-muted-foreground">
                        {exam.fecha} - {exam.medicoSolicitante}
                      </p>
                    </div>
                    <span className="px-3 py-1 bg-warning/10 text-warning rounded-full text-sm font-medium">
                      En proceso
                    </span>
                  </div>
                ))}
            </div>
          )}

          {/* Empty State */}
          {userExamenes.length === 0 && (
            <div className="bg-card border border-border rounded-2xl p-12 text-center">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <TestTube className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-lg text-foreground mb-2">No hay examenes</h3>
              <p className="text-muted-foreground">No tienes examenes registrados</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
