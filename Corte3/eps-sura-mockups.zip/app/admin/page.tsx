"use client"

import { useState } from "react"
import { 
  Users, 
  Calendar, 
  FileCheck, 
  Building2,
  TrendingUp,
  TrendingDown,
  Activity,
  Clock,
  AlertTriangle,
  CheckCircle,
  UserPlus,
  Stethoscope
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const stats = [
  {
    title: "Afiliados Activos",
    value: "125,847",
    change: "+2.5%",
    trend: "up",
    icon: Users,
    color: "text-primary"
  },
  {
    title: "Citas Este Mes",
    value: "8,542",
    change: "+12.3%",
    trend: "up",
    icon: Calendar,
    color: "text-accent"
  },
  {
    title: "Autorizaciones Pendientes",
    value: "234",
    change: "-8.1%",
    trend: "down",
    icon: FileCheck,
    color: "text-warning"
  },
  {
    title: "IPS Activas",
    value: "45",
    change: "+3",
    trend: "up",
    icon: Building2,
    color: "text-success"
  }
]

const recentAlerts = [
  {
    id: 1,
    type: "warning",
    message: "Alta demanda en urgencias - IPS Norte",
    time: "Hace 15 min"
  },
  {
    id: 2,
    type: "info",
    message: "Nuevo convenio activado con Laboratorio Central",
    time: "Hace 1 hora"
  },
  {
    id: 3,
    type: "error",
    message: "Fallo en sistema de citas - IPS Sur",
    time: "Hace 2 horas"
  },
  {
    id: 4,
    type: "success",
    message: "Actualización de tarifas completada",
    time: "Hace 3 horas"
  }
]

const pendingAuthorizations = [
  {
    id: "AUT-2024-1234",
    patient: "María García",
    type: "Cirugía ambulatoria",
    requestDate: "2024-02-15",
    priority: "alta"
  },
  {
    id: "AUT-2024-1235",
    patient: "Carlos Pérez",
    type: "Resonancia magnética",
    requestDate: "2024-02-15",
    priority: "normal"
  },
  {
    id: "AUT-2024-1236",
    patient: "Ana Rodríguez",
    type: "Medicamento especial",
    requestDate: "2024-02-14",
    priority: "urgente"
  }
]

const topDoctors = [
  { name: "Dr. Carlos Mendoza", specialty: "Medicina General", appointments: 145, rating: 4.9 },
  { name: "Dra. Ana López", specialty: "Pediatría", appointments: 132, rating: 4.8 },
  { name: "Dr. Roberto García", specialty: "Cardiología", appointments: 98, rating: 4.9 },
  { name: "Dra. María Sánchez", specialty: "Ginecología", appointments: 89, rating: 4.7 }
]

export default function AdminDashboard() {
  const [period, setPeriod] = useState("month")

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Panel de Administración</h1>
          <p className="text-muted-foreground">Bienvenido al centro de control de EPS Salud</p>
        </div>
        <div className="flex items-center gap-4">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Esta semana</SelectItem>
              <SelectItem value="month">Este mes</SelectItem>
              <SelectItem value="quarter">Este trimestre</SelectItem>
              <SelectItem value="year">Este año</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.title} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-3xl font-bold">{stat.value}</p>
                  <div className={`flex items-center gap-1 text-sm ${
                    stat.trend === "up" ? "text-success" : "text-destructive"
                  }`}>
                    {stat.trend === "up" ? (
                      <TrendingUp className="h-4 w-4" />
                    ) : (
                      <TrendingDown className="h-4 w-4" />
                    )}
                    <span>{stat.change}</span>
                    <span className="text-muted-foreground">vs mes anterior</span>
                  </div>
                </div>
                <div className={`p-3 rounded-xl bg-muted/50`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Alerts */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-primary" />
              Alertas del Sistema
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentAlerts.map((alert) => (
              <div 
                key={alert.id}
                className={`p-3 rounded-lg border ${
                  alert.type === "error" 
                    ? "bg-destructive/5 border-destructive/20" 
                    : alert.type === "warning"
                    ? "bg-warning/5 border-warning/20"
                    : alert.type === "success"
                    ? "bg-success/5 border-success/20"
                    : "bg-primary/5 border-primary/20"
                }`}
              >
                <div className="flex items-start gap-3">
                  {alert.type === "error" && <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0" />}
                  {alert.type === "warning" && <AlertTriangle className="h-5 w-5 text-warning flex-shrink-0" />}
                  {alert.type === "success" && <CheckCircle className="h-5 w-5 text-success flex-shrink-0" />}
                  {alert.type === "info" && <Activity className="h-5 w-5 text-primary flex-shrink-0" />}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{alert.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">{alert.time}</p>
                  </div>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full">
              Ver todas las alertas
            </Button>
          </CardContent>
        </Card>

        {/* Pending Authorizations */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileCheck className="h-5 w-5 text-primary" />
                Autorizaciones Pendientes
              </CardTitle>
              <Button variant="outline" size="sm">Ver todas</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingAuthorizations.map((auth) => (
                <div 
                  key={auth.id}
                  className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <FileCheck className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm text-primary">{auth.id}</span>
                        <Badge 
                          variant="outline"
                          className={
                            auth.priority === "urgente" 
                              ? "bg-destructive/10 text-destructive border-destructive/30"
                              : auth.priority === "alta"
                              ? "bg-warning/10 text-warning-foreground border-warning/30"
                              : "bg-muted"
                          }
                        >
                          {auth.priority}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium">{auth.patient}</p>
                      <p className="text-sm text-muted-foreground">{auth.type}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right mr-4">
                      <p className="text-sm text-muted-foreground">Solicitado</p>
                      <p className="text-sm font-medium">{auth.requestDate}</p>
                    </div>
                    <Button size="sm" variant="outline">Revisar</Button>
                    <Button size="sm">Aprobar</Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Doctors */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Stethoscope className="h-5 w-5 text-primary" />
              Médicos con Más Citas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topDoctors.map((doctor, index) => (
                <div key={doctor.name} className="flex items-center gap-4">
                  <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary/10 text-primary font-bold text-sm">
                    {index + 1}
                  </div>
                  <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                    <span className="font-semibold text-sm">
                      {doctor.name.split(" ").slice(1).map(n => n[0]).join("")}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{doctor.name}</p>
                    <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{doctor.appointments}</p>
                    <p className="text-sm text-muted-foreground">citas</p>
                  </div>
                  <Badge variant="secondary" className="bg-success/10 text-success">
                    {doctor.rating}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-primary" />
              Acciones Rápidas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <Button variant="outline" className="h-auto py-6 flex flex-col gap-2">
                <UserPlus className="h-6 w-6 text-primary" />
                <span>Registrar Afiliado</span>
              </Button>
              <Button variant="outline" className="h-auto py-6 flex flex-col gap-2">
                <Stethoscope className="h-6 w-6 text-primary" />
                <span>Agregar Médico</span>
              </Button>
              <Button variant="outline" className="h-auto py-6 flex flex-col gap-2">
                <Building2 className="h-6 w-6 text-primary" />
                <span>Gestionar IPS</span>
              </Button>
              <Button variant="outline" className="h-auto py-6 flex flex-col gap-2">
                <FileCheck className="h-6 w-6 text-primary" />
                <span>Autorizaciones</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Activity Chart Placeholder */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Actividad Mensual
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center bg-muted/30 rounded-lg">
            <div className="text-center">
              <Activity className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-lg font-medium text-muted-foreground">Gráfico de Actividad</p>
              <p className="text-sm text-muted-foreground">Visualización de citas, autorizaciones y registros</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
