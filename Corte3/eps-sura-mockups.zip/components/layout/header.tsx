'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useAuth } from '@/lib/auth-context'
import { 
  Bell, 
  User, 
  LogOut, 
  Menu, 
  X,
  ChevronDown,
  Settings,
  HelpCircle
} from 'lucide-react'
import { notificaciones } from '@/lib/mock-data'

export function Header() {
  const { user, logout } = useAuth()
  const [showNotifications, setShowNotifications] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const userNotifications = notificaciones.filter(n => n.usuarioId === user?.id)
  const unreadCount = userNotifications.filter(n => !n.leida).length

  const getRoleLabel = () => {
    switch (user?.rol) {
      case 'afiliado': return 'Afiliado'
      case 'medico': return 'Medico'
      case 'admin': return 'Administrador'
      default: return ''
    }
  }

  const getNavLinks = () => {
    switch (user?.rol) {
      case 'afiliado':
        return [
          { href: '/afiliado', label: 'Inicio' },
          { href: '/afiliado/citas', label: 'Mis Citas' },
          { href: '/afiliado/autorizaciones', label: 'Autorizaciones' },
          { href: '/afiliado/medicamentos', label: 'Medicamentos' },
          { href: '/afiliado/historial', label: 'Historial' },
        ]
      case 'medico':
        return [
          { href: '/medico', label: 'Inicio' },
          { href: '/medico/agenda', label: 'Mi Agenda' },
          { href: '/medico/pacientes', label: 'Pacientes' },
        ]
      case 'admin':
        return [
          { href: '/admin', label: 'Dashboard' },
          { href: '/admin/usuarios', label: 'Usuarios' },
          { href: '/admin/autorizaciones', label: 'Autorizaciones' },
          { href: '/admin/reportes', label: 'Reportes' },
        ]
      default:
        return []
    }
  }

  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <Link href={`/${user?.rol || ''}`} className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">EP</span>
              </div>
              <div className="hidden sm:block">
                <span className="text-xl font-semibold text-foreground">EPS Salud</span>
                <span className="text-xs text-muted-foreground block">Portal de Servicios</span>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {getNavLinks().map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Right side actions */}
          <div className="flex items-center gap-2">
            {/* Notifications */}
            <div className="relative">
              <button
                onClick={() => {
                  setShowNotifications(!showNotifications)
                  setShowUserMenu(false)
                }}
                className="relative p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
                aria-label="Notificaciones"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-accent text-accent-foreground text-xs font-bold rounded-full flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-card rounded-xl shadow-lg border border-border overflow-hidden">
                  <div className="px-4 py-3 border-b border-border">
                    <h3 className="font-semibold text-foreground">Notificaciones</h3>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {userNotifications.length === 0 ? (
                      <p className="px-4 py-6 text-center text-muted-foreground">
                        No tiene notificaciones
                      </p>
                    ) : (
                      userNotifications.map((notif) => (
                        <Link
                          key={notif.id}
                          href={notif.accionUrl || '#'}
                          className={`block px-4 py-3 hover:bg-muted border-b border-border last:border-0 ${
                            !notif.leida ? 'bg-primary/5' : ''
                          }`}
                          onClick={() => setShowNotifications(false)}
                        >
                          <p className="font-medium text-sm text-foreground">{notif.titulo}</p>
                          <p className="text-sm text-muted-foreground mt-1">{notif.mensaje}</p>
                          <p className="text-xs text-muted-foreground mt-1">{notif.fecha}</p>
                        </Link>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Menu */}
            <div className="relative">
              <button
                onClick={() => {
                  setShowUserMenu(!showUserMenu)
                  setShowNotifications(false)
                }}
                className="flex items-center gap-2 p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
              >
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-primary" />
                </div>
                <div className="hidden md:block text-left">
                  <p className="text-sm font-medium text-foreground">{user?.nombre}</p>
                  <p className="text-xs text-muted-foreground">{getRoleLabel()}</p>
                </div>
                <ChevronDown className="w-4 h-4 hidden md:block" />
              </button>

              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-56 bg-card rounded-xl shadow-lg border border-border overflow-hidden">
                  <div className="px-4 py-3 border-b border-border">
                    <p className="font-medium text-foreground">{user?.nombre} {user?.apellido}</p>
                    <p className="text-sm text-muted-foreground">{user?.email}</p>
                  </div>
                  <div className="py-2">
                    <Link
                      href={`/${user?.rol}/perfil`}
                      className="flex items-center gap-3 px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted"
                      onClick={() => setShowUserMenu(false)}
                    >
                      <User className="w-4 h-4" />
                      Mi Perfil
                    </Link>
                    <Link
                      href={`/${user?.rol}/configuracion`}
                      className="flex items-center gap-3 px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted"
                      onClick={() => setShowUserMenu(false)}
                    >
                      <Settings className="w-4 h-4" />
                      Configuracion
                    </Link>
                    <Link
                      href="/ayuda"
                      className="flex items-center gap-3 px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted"
                      onClick={() => setShowUserMenu(false)}
                    >
                      <HelpCircle className="w-4 h-4" />
                      Ayuda
                    </Link>
                  </div>
                  <div className="border-t border-border py-2">
                    <button
                      onClick={() => {
                        logout()
                        setShowUserMenu(false)
                      }}
                      className="flex items-center gap-3 px-4 py-2 text-sm text-destructive hover:bg-destructive/10 w-full"
                    >
                      <LogOut className="w-4 h-4" />
                      Cerrar Sesion
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg"
              aria-label="Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="lg:hidden py-4 border-t border-border">
            {getNavLinks().map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="block px-4 py-3 text-base font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg"
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.label}
              </Link>
            ))}
          </nav>
        )}
      </div>
    </header>
  )
}
