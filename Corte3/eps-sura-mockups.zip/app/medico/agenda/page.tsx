'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { citas } from '@/lib/mock-data'
import {
  Calendar,
  Clock,
  User,
  Video,
  Building2,
  ChevronLeft,
  ChevronRight,
  Phone,
  FileText,
  Play,
  CheckCircle2,
  X
} from 'lucide-react'

export default function AgendaMedicoPage() {
  const { user } = useAuth()
  const [selectedDate, setSelectedDate] = useState('2026-04-25')
  const [selectedCita, setSelectedCita] = useState<typeof citas[0] | null>(null)

  const medicoCitas = citas.filter(c => c.medicoId === user?.id)
  const citasDelDia = medicoCitas.filter(c => c.fecha === selectedDate)

  // Generate week dates
  const generateWeekDates = () => {
    const dates = []
    const baseDate = new Date(selectedDate)
    const dayOfWeek = baseDate.getDay()
    const startOfWeek = new Date(baseDate)
    startOfWeek.setDate(baseDate.getDate() - dayOfWeek + 1) // Start from Monday

    for (let i = 0; i < 7; i++) {
      const date = new Date(startOfWeek)
      date.setDate(startOfWeek.getDate() + i)
      dates.push(date.toISOString().split('T')[0])
    }
    return dates
  }

  const weekDates = generateWeekDates()

  const timeSlots = [
    '07:00', '07:30', '08:00', '08:30', '09:00', '09:30',
    '10:00', '10:30', '11:00', '11:30', '12:00', '12:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'
  ]

  const getCitaForSlot = (time: string) => {
    return citasDelDia.find(c => c.hora === time)
  }

  const getStatusColor = (estado: string) => {
    switch (estado) {
      case 'confirmada': return 'bg-success/10 border-success/30 text-success'
      case 'programada': return 'bg-warning/10 border-warning/30 text-warning'
      case 'completada': return 'bg-muted border-border text-muted-foreground'
      case 'en_curso': return 'bg-chart-3/10 border-chart-3/30 text-chart-3'
      default: return 'bg-muted border-border text-muted-foreground'
    }
  }

  const navigateWeek = (direction: 'prev' | 'next') => {
    const current = new Date(selectedDate)
    current.setDate(current.getDate() + (direction === 'next' ? 7 : -7))
    setSelectedDate(current.toISOString().split('T')[0])
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Mi Agenda</h1>
          <p className="text-muted-foreground mt-1">Gestiona tus citas y consultas programadas</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigateWeek('prev')}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-muted-foreground" />
          </button>
          <span className="text-sm font-medium text-foreground px-3">
            {new Date(weekDates[0]).toLocaleDateString('es-CO', { month: 'long', year: 'numeric' })}
          </span>
          <button
            onClick={() => navigateWeek('next')}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* Week View */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {weekDates.map((date) => {
          const dateObj = new Date(date)
          const citasCount = medicoCitas.filter(c => c.fecha === date).length
          const isSelected = date === selectedDate
          const isToday = date === '2026-04-25'

          return (
            <button
              key={date}
              onClick={() => setSelectedDate(date)}
              className={`flex-shrink-0 w-20 p-3 rounded-xl border text-center transition-colors ${
                isSelected
                  ? 'border-primary bg-primary/5'
                  : 'border-border hover:border-primary/50'
              }`}
            >
              <span className="block text-xs text-muted-foreground uppercase">
                {dateObj.toLocaleDateString('es-CO', { weekday: 'short' })}
              </span>
              <span className={`block text-lg font-bold ${isToday ? 'text-primary' : 'text-foreground'}`}>
                {dateObj.getDate()}
              </span>
              {citasCount > 0 && (
                <span className="block text-xs text-primary font-medium">
                  {citasCount} cita(s)
                </span>
              )}
            </button>
          )
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Schedule */}
        <div className="lg:col-span-2 bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border">
            <h2 className="font-semibold text-lg text-foreground">
              {new Date(selectedDate).toLocaleDateString('es-CO', { 
                weekday: 'long', 
                day: 'numeric', 
                month: 'long' 
              })}
            </h2>
          </div>
          
          <div className="divide-y divide-border max-h-[600px] overflow-y-auto">
            {timeSlots.map((time) => {
              const cita = getCitaForSlot(time)
              
              return (
                <div
                  key={time}
                  className={`flex items-stretch ${cita ? 'cursor-pointer hover:bg-muted/50' : ''}`}
                  onClick={() => cita && setSelectedCita(cita)}
                >
                  <div className="w-20 py-4 px-4 text-sm font-medium text-muted-foreground border-r border-border flex-shrink-0">
                    {time}
                  </div>
                  <div className="flex-1 p-3">
                    {cita ? (
                      <div className={`p-3 rounded-xl border ${getStatusColor(cita.estado)}`}>
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="font-medium text-foreground">{cita.pacienteNombre}</p>
                            <p className="text-sm text-muted-foreground mt-0.5">{cita.motivo}</p>
                          </div>
                          <span className="flex items-center gap-1 text-xs">
                            {cita.tipo === 'virtual' ? (
                              <Video className="w-4 h-4" />
                            ) : (
                              <Building2 className="w-4 h-4" />
                            )}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="h-12 flex items-center">
                        <span className="text-sm text-muted-foreground/50">Disponible</span>
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Appointment Details */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border">
            <h2 className="font-semibold text-lg text-foreground">Detalles de la cita</h2>
          </div>
          
          {selectedCita ? (
            <div className="p-6 space-y-6">
              {/* Patient Info */}
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center">
                  <User className="w-7 h-7 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">{selectedCita.pacienteNombre}</p>
                  <p className="text-sm text-muted-foreground">Paciente</p>
                </div>
              </div>

              {/* Appointment Details */}
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span className="text-foreground">
                    {new Date(selectedCita.fecha).toLocaleDateString('es-CO', {
                      weekday: 'long',
                      day: 'numeric',
                      month: 'long'
                    })}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-foreground">{selectedCita.hora}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  {selectedCita.tipo === 'virtual' ? (
                    <>
                      <Video className="w-4 h-4 text-muted-foreground" />
                      <span className="text-foreground">Consulta virtual</span>
                    </>
                  ) : (
                    <>
                      <Building2 className="w-4 h-4 text-muted-foreground" />
                      <span className="text-foreground">{selectedCita.consultorio}</span>
                    </>
                  )}
                </div>
              </div>

              {/* Reason */}
              {selectedCita.motivo && (
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Motivo de consulta</p>
                  <p className="text-foreground">{selectedCita.motivo}</p>
                </div>
              )}

              {/* Status */}
              <div>
                <p className="text-sm text-muted-foreground mb-2">Estado</p>
                <span className={`px-3 py-1.5 rounded-full text-sm font-medium capitalize ${getStatusColor(selectedCita.estado)}`}>
                  {selectedCita.estado === 'en_curso' ? 'En curso' : selectedCita.estado}
                </span>
              </div>

              {/* Actions */}
              <div className="space-y-2 pt-4 border-t border-border">
                {(selectedCita.estado === 'confirmada' || selectedCita.estado === 'programada') && (
                  <>
                    <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors">
                      <Play className="w-4 h-4" />
                      Iniciar consulta
                    </button>
                    {selectedCita.tipo === 'virtual' && (
                      <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-chart-3 text-white rounded-xl font-medium hover:bg-chart-3/90 transition-colors">
                        <Video className="w-4 h-4" />
                        Unirse a videollamada
                      </button>
                    )}
                  </>
                )}
                
                <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-muted text-foreground rounded-xl font-medium hover:bg-muted/80 transition-colors">
                  <FileText className="w-4 h-4" />
                  Ver historial del paciente
                </button>
                
                {selectedCita.estado === 'en_curso' && (
                  <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-success text-success-foreground rounded-xl font-medium hover:bg-success/90 transition-colors">
                    <CheckCircle2 className="w-4 h-4" />
                    Finalizar consulta
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="p-6 text-center py-12">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground">
                Selecciona una cita para ver los detalles
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
