import type { User, Cita, Autorizacion, Medicamento, HistorialMedico, ResultadoExamen, Notificacion } from './types'

export const usuarios: User[] = [
  {
    id: 'afiliado-1',
    nombre: 'Maria',
    apellido: 'Garcia Lopez',
    email: 'maria.garcia@email.com',
    documento: '1234567890',
    tipoDocumento: 'CC',
    telefono: '3001234567',
    direccion: 'Calle 45 #23-12',
    ciudad: 'Medellin',
    fechaNacimiento: '1985-03-15',
    genero: 'F',
    rol: 'afiliado',
    tipoAfiliacion: 'cotizante',
    planSalud: 'Plan Oro',
    grupoFamiliar: ['beneficiario-1', 'beneficiario-2']
  },
  {
    id: 'medico-1',
    nombre: 'Carlos',
    apellido: 'Rodriguez Mejia',
    email: 'carlos.rodriguez@eps.com',
    documento: '9876543210',
    tipoDocumento: 'CC',
    telefono: '3009876543',
    direccion: 'Carrera 70 #32-45',
    ciudad: 'Medellin',
    fechaNacimiento: '1978-08-22',
    genero: 'M',
    rol: 'medico',
    especialidad: 'Medicina General',
    registroMedico: 'RM-12345',
    consultorio: 'Consultorio 305'
  },
  {
    id: 'medico-2',
    nombre: 'Ana',
    apellido: 'Martinez Ruiz',
    email: 'ana.martinez@eps.com',
    documento: '5678901234',
    tipoDocumento: 'CC',
    telefono: '3005678901',
    direccion: 'Calle 10 #50-30',
    ciudad: 'Medellin',
    fechaNacimiento: '1982-11-05',
    genero: 'F',
    rol: 'medico',
    especialidad: 'Cardiologia',
    registroMedico: 'RM-67890',
    consultorio: 'Consultorio 412'
  },
  {
    id: 'admin-1',
    nombre: 'Juan',
    apellido: 'Perez Gomez',
    email: 'admin@eps.com',
    documento: '1122334455',
    tipoDocumento: 'CC',
    telefono: '3001122334',
    direccion: 'Avenida 80 #45-20',
    ciudad: 'Medellin',
    fechaNacimiento: '1990-06-18',
    genero: 'M',
    rol: 'admin'
  }
]

export const citas: Cita[] = [
  {
    id: 'cita-1',
    pacienteId: 'afiliado-1',
    pacienteNombre: 'Maria Garcia Lopez',
    medicoId: 'medico-1',
    medicoNombre: 'Dr. Carlos Rodriguez',
    especialidad: 'Medicina General',
    fecha: '2026-04-28',
    hora: '09:00',
    estado: 'confirmada',
    tipo: 'presencial',
    consultorio: 'Consultorio 305',
    motivo: 'Control general'
  },
  {
    id: 'cita-2',
    pacienteId: 'afiliado-1',
    pacienteNombre: 'Maria Garcia Lopez',
    medicoId: 'medico-2',
    medicoNombre: 'Dra. Ana Martinez',
    especialidad: 'Cardiologia',
    fecha: '2026-05-05',
    hora: '14:30',
    estado: 'programada',
    tipo: 'presencial',
    consultorio: 'Consultorio 412',
    motivo: 'Evaluacion cardiaca'
  },
  {
    id: 'cita-3',
    pacienteId: 'afiliado-1',
    pacienteNombre: 'Maria Garcia Lopez',
    medicoId: 'medico-1',
    medicoNombre: 'Dr. Carlos Rodriguez',
    especialidad: 'Medicina General',
    fecha: '2026-03-15',
    hora: '10:00',
    estado: 'completada',
    tipo: 'virtual',
    motivo: 'Seguimiento tratamiento'
  }
]

export const autorizaciones: Autorizacion[] = [
  {
    id: 'auth-1',
    pacienteId: 'afiliado-1',
    pacienteNombre: 'Maria Garcia Lopez',
    tipo: 'procedimiento',
    descripcion: 'Ecocardiograma transtoracico',
    medicoSolicitante: 'Dra. Ana Martinez',
    fechaSolicitud: '2026-04-20',
    estado: 'aprobada',
    fechaRespuesta: '2026-04-22',
    prioridad: 'normal'
  },
  {
    id: 'auth-2',
    pacienteId: 'afiliado-1',
    pacienteNombre: 'Maria Garcia Lopez',
    tipo: 'examen',
    descripcion: 'Resonancia magnetica de rodilla derecha',
    medicoSolicitante: 'Dr. Pedro Sanchez',
    fechaSolicitud: '2026-04-23',
    estado: 'pendiente',
    prioridad: 'normal'
  },
  {
    id: 'auth-3',
    pacienteId: 'afiliado-1',
    pacienteNombre: 'Maria Garcia Lopez',
    tipo: 'medicamento',
    descripcion: 'Atorvastatina 40mg - Tratamiento cronico',
    medicoSolicitante: 'Dra. Ana Martinez',
    fechaSolicitud: '2026-04-18',
    fechaRespuesta: '2026-04-19',
    estado: 'aprobada',
    prioridad: 'urgente'
  }
]

export const medicamentos: Medicamento[] = [
  {
    id: 'med-1',
    nombre: 'Losartan',
    principioActivo: 'Losartan potasico',
    presentacion: 'Tableta 50mg',
    dosis: '1 tableta',
    frecuencia: 'Cada 12 horas',
    duracion: '30 dias',
    fechaInicio: '2026-04-01',
    fechaFin: '2026-05-01',
    medicoId: 'medico-2',
    medicoNombre: 'Dra. Ana Martinez',
    estado: 'activo',
    instrucciones: 'Tomar con alimentos. No suspender sin indicacion medica.',
    reclamosPendientes: 2
  },
  {
    id: 'med-2',
    nombre: 'Metformina',
    principioActivo: 'Metformina clorhidrato',
    presentacion: 'Tableta 850mg',
    dosis: '1 tableta',
    frecuencia: 'Con cada comida principal',
    duracion: '30 dias',
    fechaInicio: '2026-04-01',
    fechaFin: '2026-05-01',
    medicoId: 'medico-1',
    medicoNombre: 'Dr. Carlos Rodriguez',
    estado: 'activo',
    instrucciones: 'Tomar durante o despues de las comidas para evitar molestias gastricas.'
  },
  {
    id: 'med-3',
    nombre: 'Acetaminofen',
    principioActivo: 'Paracetamol',
    presentacion: 'Tableta 500mg',
    dosis: '1-2 tabletas',
    frecuencia: 'Cada 6 horas si hay dolor',
    duracion: '7 dias',
    fechaInicio: '2026-04-15',
    fechaFin: '2026-04-22',
    medicoId: 'medico-1',
    medicoNombre: 'Dr. Carlos Rodriguez',
    estado: 'completado',
    instrucciones: 'No exceder 4 gramos al dia.'
  }
]

export const historialMedico: HistorialMedico[] = [
  {
    id: 'hist-1',
    pacienteId: 'afiliado-1',
    fecha: '2026-03-15',
    tipo: 'consulta',
    medicoNombre: 'Dr. Carlos Rodriguez',
    especialidad: 'Medicina General',
    diagnostico: 'Hipertension arterial controlada',
    descripcion: 'Paciente asiste a control. Se observa mejoria en cifras tensionales. Se ajusta medicacion.'
  },
  {
    id: 'hist-2',
    pacienteId: 'afiliado-1',
    fecha: '2026-02-20',
    tipo: 'examen',
    medicoNombre: 'Dr. Carlos Rodriguez',
    especialidad: 'Laboratorio Clinico',
    diagnostico: 'Perfil lipidico alterado',
    descripcion: 'Colesterol total elevado. Trigliceridos en rango normal. Se recomienda dieta y ejercicio.',
    resultados: 'Colesterol Total: 245 mg/dL, HDL: 45 mg/dL, LDL: 160 mg/dL, Trigliceridos: 150 mg/dL'
  },
  {
    id: 'hist-3',
    pacienteId: 'afiliado-1',
    fecha: '2026-01-10',
    tipo: 'consulta',
    medicoNombre: 'Dra. Ana Martinez',
    especialidad: 'Cardiologia',
    diagnostico: 'Evaluacion cardiovascular',
    descripcion: 'Primera valoracion por cardiologia. EKG normal. Se solicita ecocardiograma de control.'
  }
]

export const resultadosExamenes: ResultadoExamen[] = [
  {
    id: 'exam-1',
    pacienteId: 'afiliado-1',
    nombre: 'Hemograma completo',
    tipo: 'laboratorio',
    fecha: '2026-04-20',
    estado: 'listo',
    medicoSolicitante: 'Dr. Carlos Rodriguez'
  },
  {
    id: 'exam-2',
    pacienteId: 'afiliado-1',
    nombre: 'Perfil tiroideo',
    tipo: 'laboratorio',
    fecha: '2026-04-23',
    estado: 'pendiente',
    medicoSolicitante: 'Dr. Carlos Rodriguez'
  },
  {
    id: 'exam-3',
    pacienteId: 'afiliado-1',
    nombre: 'Radiografia de torax',
    tipo: 'imagenologia',
    fecha: '2026-04-18',
    estado: 'listo',
    medicoSolicitante: 'Dra. Ana Martinez'
  }
]

export const notificaciones: Notificacion[] = [
  {
    id: 'notif-1',
    usuarioId: 'afiliado-1',
    titulo: 'Cita confirmada',
    mensaje: 'Su cita con Dr. Carlos Rodriguez para el 28 de abril ha sido confirmada.',
    tipo: 'cita',
    fecha: '2026-04-25',
    leida: false,
    accionUrl: '/afiliado/citas'
  },
  {
    id: 'notif-2',
    usuarioId: 'afiliado-1',
    titulo: 'Autorizacion aprobada',
    mensaje: 'Su autorizacion para Ecocardiograma ha sido aprobada.',
    tipo: 'autorizacion',
    fecha: '2026-04-22',
    leida: true,
    accionUrl: '/afiliado/autorizaciones'
  },
  {
    id: 'notif-3',
    usuarioId: 'afiliado-1',
    titulo: 'Recordatorio de medicamento',
    mensaje: 'Recuerde reclamar sus medicamentos pendientes en la farmacia.',
    tipo: 'medicamento',
    fecha: '2026-04-24',
    leida: false,
    accionUrl: '/afiliado/medicamentos'
  }
]

export const especialidades = [
  'Medicina General',
  'Cardiologia',
  'Dermatologia',
  'Endocrinologia',
  'Gastroenterologia',
  'Ginecologia',
  'Neurologia',
  'Oftalmologia',
  'Ortopedia',
  'Otorrinolaringologia',
  'Pediatria',
  'Psiquiatria',
  'Urologia'
]

export const sedes = [
  { id: 'sede-1', nombre: 'Sede Centro', direccion: 'Carrera 45 #52-12', ciudad: 'Medellin' },
  { id: 'sede-2', nombre: 'Sede Poblado', direccion: 'Calle 10 #43-20', ciudad: 'Medellin' },
  { id: 'sede-3', nombre: 'Sede Laureles', direccion: 'Circular 73 #39-15', ciudad: 'Medellin' },
  { id: 'sede-4', nombre: 'Sede Envigado', direccion: 'Carrera 43A #27-80', ciudad: 'Envigado' }
]
