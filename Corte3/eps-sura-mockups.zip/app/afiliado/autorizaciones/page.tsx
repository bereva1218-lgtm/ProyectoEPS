'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useAuth } from '@/lib/auth-context'
import { autorizaciones } from '@/lib/mock-data'
import {
  FileText,
  Plus,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Search,
  Filter,
  ChevronDown,
  ChevronUp,
  Calendar,
  User,
  FileCheck
} from 'lucide-react'

export default function AutorizacionesPage() {
  const { user } = useAuth()
  const [filter, setFilter] = useState<'todas' | 'pendiente' | 'aprobada' | 'rechazada'>('todas')
  const [expandedItems, setExpandedItems] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState('')

  const userAutorizaciones = autorizaciones.filter(a => a.pacienteId === user?.id)

  const filteredAutorizaciones = userAutorizaciones
    .filter(a => filter === 'todas' || a.estado === filter)
    .filter(a =>
      a.descripcion.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.medicoSolicitante.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.tipo.toLowerCase().includes(searchQuery.toLowerCase())
    )

  const toggleExpand = (id: string) => {
    setExpandedItems(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  const getStatusIcon = (estado: string) => {
    switch (estado) {
      case 'aprobada': return CheckCircle2
      case 'pendiente': return Clock
      case 'rechazada': return XCircle
      case 'en_revision': return AlertCircle
      default: return FileText
    }
  }

  const getStatusColor = (estado: string) => {
    switch (estado) {
      case 'aprobada': return 'bg-success/10 text-success border-success/20'
      case 'pendiente': return 'bg-warning/10 text-warning border-warning/20'
      case 'rechazada': return 'bg-destructive/10 text-destructive border-destructive/20'
      case 'en_revision': return 'bg-chart-3/10 text-chart-3 border-chart-3/20'
      default: return 'bg-muted text-muted-foreground border-border'
    }
  }

  const getTypeLabel = (tipo: string) => {
    const labels: Record<string, string> = {
      'procedimiento': 'Procedimiento',
      'medicamento': 'Medicamento',
      'examen': 'Examen',
      'hospitalizacion': 'Hospitalizacion',
      'cirugia': 'Cirugia'
    }
    return labels[tipo] || tipo
  }

  const stats = {
    total: userAutorizaciones.length,
    pendientes: userAutorizaciones.filter(a => a.estado === 'pendiente' || a.estado === 'en_revision').length,
    aprobadas: userAutorizaciones.filter(a => a.estado === 'aprobada').length,
    rechazadas: userAutorizaciones.filter(a => a.estado === 'rechazada').length,
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Autorizaciones</h1>
          <p className="text-muted-foreground mt-1">Gestiona tus solicitudes de autorizacion medica</p>
        </div>
        <Link
          href="/afiliado/autorizaciones/nueva"
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Nueva solicitud
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Total</p>
          <p className="text-2xl font-bold text-foreground mt-1">{stats.total}</p>
        </div>
        <div className="bg-card border border-warning/20 rounded-xl p-4">
          <p className="text-sm text-warning">Pendientes</p>
          <p className="text-2xl font-bold text-warning mt-1">{stats.pendientes}</p>
        </div>
        <div className="bg-card border border-success/20 rounded-xl p-4">
          <p className="text-sm text-success">Aprobadas</p>
          <p className="text-2xl font-bold text-success mt-1">{stats.aprobadas}</p>
        </div>
        <div className="bg-card border border-destructive/20 rounded-xl p-4">
          <p className="text-sm text-destructive">Rechazadas</p>
          <p className="text-2xl font-bold text-destructive mt-1">{stats.rechazadas}</p>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Buscar autorizaciones..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
          {[
            { value: 'todas', label: 'Todas' },
            { value: 'pendiente', label: 'Pendientes' },
            { value: 'aprobada', label: 'Aprobadas' },
            { value: 'rechazada', label: 'Rechazadas' },
          ].map((f) => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value as typeof filter)}
              className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                filter === f.value
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:text-foreground'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Autorizaciones List */}
      <div className="space-y-4">
        {filteredAutorizaciones.length > 0 ? (
          filteredAutorizaciones.map((auth) => {
            const StatusIcon = getStatusIcon(auth.estado)
            const isExpanded = expandedItems.includes(auth.id)

            return (
              <div
                key={auth.id}
                className={`bg-card border rounded-2xl overflow-hidden ${getStatusColor(auth.estado).split(' ')[2]}`}
              >
                <button
                  onClick={() => toggleExpand(auth.id)}
                  className="w-full p-5 flex items-start gap-4 text-left hover:bg-muted/50 transition-colors"
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${getStatusColor(auth.estado).split(' ').slice(0, 2).join(' ')}`}>
                    <StatusIcon className="w-6 h-6" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="font-semibold text-foreground">{auth.descripcion}</p>
                        <div className="flex flex-wrap items-center gap-3 mt-2 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1.5">
                            <User className="w-4 h-4" />
                            {auth.medicoSolicitante}
                          </span>
                          <span className="flex items-center gap-1.5">
                            <Calendar className="w-4 h-4" />
                            {auth.fechaSolicitud}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {auth.prioridad === 'urgente' && (
                          <span className="px-2 py-0.5 bg-destructive/10 text-destructive text-xs font-medium rounded">
                            Urgente
                          </span>
                        )}
                        {isExpanded ? (
                          <ChevronUp className="w-5 h-5 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-muted-foreground" />
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mt-3">
                      <span className="px-2.5 py-1 bg-muted text-muted-foreground rounded text-xs font-medium">
                        {getTypeLabel(auth.tipo)}
                      </span>
                      <span className={`px-2.5 py-1 rounded text-xs font-medium capitalize ${getStatusColor(auth.estado).split(' ').slice(0, 2).join(' ')}`}>
                        {auth.estado === 'en_revision' ? 'En revision' : auth.estado}
                      </span>
                    </div>
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-5 pb-5 pt-0 border-t border-border">
                    <div className="pt-4 space-y-4">
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Fecha de solicitud</p>
                          <p className="font-medium text-foreground">{auth.fechaSolicitud}</p>
                        </div>
                        {auth.fechaRespuesta && (
                          <div>
                            <p className="text-sm text-muted-foreground">Fecha de respuesta</p>
                            <p className="font-medium text-foreground">{auth.fechaRespuesta}</p>
                          </div>
                        )}
                      </div>

                      {auth.comentarios && (
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">Comentarios</p>
                          <p className="text-foreground">{auth.comentarios}</p>
                        </div>
                      )}

                      {auth.estado === 'aprobada' && (
                        <div className="bg-success/10 border border-success/20 rounded-xl p-4">
                          <div className="flex items-center gap-2">
                            <FileCheck className="w-5 h-5 text-success" />
                            <span className="font-medium text-foreground">Autorizacion aprobada</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            Puede proceder a programar su cita o procedimiento.
                          </p>
                        </div>
                      )}

                      {auth.estado === 'rechazada' && (
                        <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-4">
                          <div className="flex items-center gap-2">
                            <XCircle className="w-5 h-5 text-destructive" />
                            <span className="font-medium text-foreground">Autorizacion rechazada</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            Puede presentar una apelacion o comunicarse con servicio al cliente.
                          </p>
                          <button className="mt-3 text-sm text-primary font-medium hover:underline">
                            Solicitar revision
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )
          })
        ) : (
          <div className="bg-card border border-border rounded-2xl p-12 text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-lg text-foreground mb-2">No hay autorizaciones</h3>
            <p className="text-muted-foreground mb-6">
              {searchQuery || filter !== 'todas'
                ? 'No se encontraron autorizaciones con los filtros aplicados'
                : 'No tienes solicitudes de autorizacion'}
            </p>
            <Link
              href="/afiliado/autorizaciones/nueva"
              className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Nueva solicitud
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
