"use client"

import { useState } from "react"
import { 
  FileText, 
  Search, 
  Filter,
  Clock,
  CheckCircle,
  XCircle,
  Eye,
  Plus,
  Calendar,
  User
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

const orders = [
  {
    id: "ORD-001",
    patient: "María García López",
    patientId: "1.234.567.890",
    type: "Laboratorio",
    description: "Hemograma completo, glucosa, creatinina",
    date: "2024-02-15",
    status: "pendiente",
    priority: "normal"
  },
  {
    id: "ORD-002",
    patient: "Carlos Martínez",
    patientId: "9.876.543.210",
    type: "Imagenología",
    description: "Radiografía de tórax PA y lateral",
    date: "2024-02-14",
    status: "completada",
    priority: "urgente"
  },
  {
    id: "ORD-003",
    patient: "Ana Rodríguez",
    patientId: "5.555.666.777",
    type: "Interconsulta",
    description: "Valoración por cardiología",
    date: "2024-02-14",
    status: "en_proceso",
    priority: "alta"
  },
  {
    id: "ORD-004",
    patient: "Pedro Sánchez",
    patientId: "1.111.222.333",
    type: "Laboratorio",
    description: "Perfil lipídico, HbA1c",
    date: "2024-02-13",
    status: "completada",
    priority: "normal"
  },
  {
    id: "ORD-005",
    patient: "Laura Gómez",
    patientId: "4.444.555.666",
    type: "Procedimiento",
    description: "Electrocardiograma",
    date: "2024-02-13",
    status: "cancelada",
    priority: "normal"
  }
]

const statusConfig = {
  pendiente: { label: "Pendiente", color: "bg-warning/10 text-warning-foreground border-warning/30", icon: Clock },
  en_proceso: { label: "En proceso", color: "bg-primary/10 text-primary border-primary/30", icon: Clock },
  completada: { label: "Completada", color: "bg-success/10 text-success border-success/30", icon: CheckCircle },
  cancelada: { label: "Cancelada", color: "bg-destructive/10 text-destructive border-destructive/30", icon: XCircle }
}

const priorityConfig = {
  normal: { label: "Normal", color: "bg-muted text-muted-foreground" },
  alta: { label: "Alta", color: "bg-warning/20 text-warning-foreground" },
  urgente: { label: "Urgente", color: "bg-destructive/20 text-destructive" }
}

export default function OrdenesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")
  const [isNewOrderOpen, setIsNewOrderOpen] = useState(false)

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.patient.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.id.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || order.status === statusFilter
    const matchesType = typeFilter === "all" || order.type === typeFilter
    return matchesSearch && matchesStatus && matchesType
  })

  const orderStats = {
    total: orders.length,
    pendientes: orders.filter(o => o.status === "pendiente").length,
    enProceso: orders.filter(o => o.status === "en_proceso").length,
    completadas: orders.filter(o => o.status === "completada").length
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Órdenes Médicas</h1>
          <p className="text-muted-foreground">Gestione las órdenes de laboratorio, imagenología e interconsultas</p>
        </div>
        <Dialog open={isNewOrderOpen} onOpenChange={setIsNewOrderOpen}>
          <DialogTrigger asChild>
            <Button size="lg">
              <Plus className="h-5 w-5 mr-2" />
              Nueva Orden
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Crear Nueva Orden</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <Label>Paciente</Label>
                <Input placeholder="Buscar paciente..." className="mt-1" />
              </div>
              <div>
                <Label>Tipo de orden</Label>
                <Select>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Seleccionar tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="laboratorio">Laboratorio</SelectItem>
                    <SelectItem value="imagenologia">Imagenología</SelectItem>
                    <SelectItem value="interconsulta">Interconsulta</SelectItem>
                    <SelectItem value="procedimiento">Procedimiento</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Prioridad</Label>
                <Select>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Seleccionar prioridad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="urgente">Urgente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Descripción</Label>
                <Textarea 
                  placeholder="Describa los exámenes o procedimientos requeridos..."
                  className="mt-1 min-h-[100px]"
                />
              </div>
              <div>
                <Label>Indicaciones especiales</Label>
                <Textarea 
                  placeholder="Indicaciones adicionales para el paciente..."
                  className="mt-1"
                />
              </div>
              <div className="flex gap-2 pt-4">
                <Button variant="outline" className="flex-1" onClick={() => setIsNewOrderOpen(false)}>
                  Cancelar
                </Button>
                <Button className="flex-1" onClick={() => setIsNewOrderOpen(false)}>
                  Crear Orden
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{orderStats.total}</p>
                <p className="text-sm text-muted-foreground">Total órdenes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-warning/10">
                <Clock className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{orderStats.pendientes}</p>
                <p className="text-sm text-muted-foreground">Pendientes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Clock className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{orderStats.enProceso}</p>
                <p className="text-sm text-muted-foreground">En proceso</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10">
                <CheckCircle className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{orderStats.completadas}</p>
                <p className="text-sm text-muted-foreground">Completadas</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por paciente o número de orden..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los estados</SelectItem>
                <SelectItem value="pendiente">Pendiente</SelectItem>
                <SelectItem value="en_proceso">En proceso</SelectItem>
                <SelectItem value="completada">Completada</SelectItem>
                <SelectItem value="cancelada">Cancelada</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los tipos</SelectItem>
                <SelectItem value="Laboratorio">Laboratorio</SelectItem>
                <SelectItem value="Imagenología">Imagenología</SelectItem>
                <SelectItem value="Interconsulta">Interconsulta</SelectItem>
                <SelectItem value="Procedimiento">Procedimiento</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Orders List */}
      <div className="space-y-4">
        {filteredOrders.map((order) => {
          const statusInfo = statusConfig[order.status as keyof typeof statusConfig]
          const priorityInfo = priorityConfig[order.priority as keyof typeof priorityConfig]
          const StatusIcon = statusInfo.icon

          return (
            <Card key={order.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-mono text-sm font-medium text-primary">{order.id}</span>
                      <Badge variant="outline" className={statusInfo.color}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {statusInfo.label}
                      </Badge>
                      <Badge variant="secondary" className={priorityInfo.color}>
                        {priorityInfo.label}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 mb-1">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{order.patient}</span>
                      <span className="text-sm text-muted-foreground">CC: {order.patientId}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      <span className="font-medium text-foreground">{order.type}:</span> {order.description}
                    </p>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>{order.date}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-1" />
                      Ver detalles
                    </Button>
                    {order.status === "completada" && (
                      <Button size="sm">
                        Ver resultados
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {filteredOrders.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-lg font-medium text-muted-foreground">No se encontraron órdenes</p>
            <p className="text-sm text-muted-foreground">Intente ajustar los filtros de búsqueda</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
