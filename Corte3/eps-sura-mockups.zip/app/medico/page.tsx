'use client'

import Link from 'next/link'
import { useAuth } from '@/lib/auth-context'
import { citas } from '@/lib/mock-data'
import {
  Calendar,
  Users,
  Clock,
  ChevronRight,
  Video,
  Building2,
  FileText,
  Stethoscope,
  Activity
} from 'lucide-react'

export default function MedicoDashboard() {
  const { user } = useAuth()

  const medicoCitas = citas.filter(c => c.medicoId === user?.id)
  const citasHoy = medicoCitas.filter(c => c.fecha === '2026-04-25')
  const citasProgramadas = medicoCitas.filter(c => c.estado === 'programada' || c.estado === 'confirmada')
  const citasCompletadas = medicoCitas.filter(c => c.estado === 'completada')
  
  // Next appointment
  const proximaCita = citasProgramadas.sort((a, b) => {
    const dateA = new Date(`${a.fecha}T${a.hora}`)
    const dateB = new Date(`${b.fecha}T${b.hora}`)
    return dateA.getTime() - dateB.getTime()
  })[0]

  const stats = [
    { label: 'Citas hoy', value: citasHoy.length, icon: Calendar, color: 'text-chart-1' },
    { label: 'Programadas', value: citasProgramadas.length, icon: Clock, color: 'text-chart-2' },
    { label: 'Pacientes atendidos', value: citasCompletadas.length, icon: Users, color: 'text-chart-3' },
    { label: 'Este mes', value: medicoCitas.length, icon: Activity, color: 'text-chart-4' },
  ]

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="bg-card rounded-2xl p-6 border border-border">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              Bienvenido, Dr. {user?.apellido}
            </h1>
            <p className="text-muted-foreground mt-1">
              {user?.especialidad} - {user?.consultorio}
            </p>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="px-3 py-1 bg-primary/10 text-primary rounded-full font-medium">
              RM: {user?.registroMedico}
            </span>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-card border border-border rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Next Appointment */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border flex items-center justify-between">
            <h2 className="font-semibold text-lg text-foreground">Proxima cita</h2>
            <Link href="/medico/agenda" className="text-primary text-sm font-medium hover:underline flex items-center gap-1">
              Ver agenda <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          
          {proximaCita ? (
            <div className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 bg-primary/10 rounded-xl flex flex-col items-center justify-center flex-shrink-0">
                  <span className="text-2xl font-bold text-primary">
                    {new Date(proximaCita.fecha).getDate()}
                  </span>
                  <span className="text-xs text-primary uppercase">
                    {new Date(proximaCita.fecha).toLocaleDateString('es-CO', { month: 'short' })}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground">{proximaCita.pacienteNombre}</h3>
                  <p className="text-muted-foreground text-sm mt-1">{proximaCita.motivo}</p>
                  
                  <div className="flex flex-wrap gap-4 mt-3 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4" />
                      {proximaCita.hora}
                    </span>
                    <span className="flex items-center gap-1.5">
                      {proximaCita.tipo === 'presencial' ? (
                        <>
                          <Building2 className="w-4 h-4" />
                          Presencial
                        </>
                      ) : (
                        <>
                          <Video className="w-4 h-4" />
                          Virtual
                        </>
                      )}
                    </span>
                  </div>
                  
                  <div className="mt-4 flex gap-2">
                    <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                      Iniciar consulta
                    </button>
                    <button className="px-4 py-2 bg-muted text-foreground rounded-lg text-sm font-medium hover:bg-muted/80 transition-colors">
                      Ver historial
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-6 text-center">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground">No hay citas programadas</p>
            </div>
          )}
        </div>

        {/* Today's Schedule */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border">
            <h2 className="font-semibold text-lg text-foreground">Agenda de hoy</h2>
          </div>
          
          <div className="p-6">
            {citasHoy.length > 0 ? (
              <div className="space-y-3">
                {citasHoy.map((cita) => (
                  <div
                    key={cita.id}
                    className="flex items-center gap-4 p-3 bg-muted/50 rounded-xl"
                  >
                    <div className="text-center min-w-[60px]">
                      <p className="font-semibold text-foreground">{cita.hora}</p>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">{cita.pacienteNombre}</p>
                      <p className="text-sm text-muted-foreground truncate">{cita.motivo}</p>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                      cita.tipo === 'virtual' 
                        ? 'bg-chart-3/10 text-chart-3' 
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      {cita.tipo === 'virtual' ? 'Virtual' : 'Presencial'}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No hay citas programadas para hoy</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid sm:grid-cols-3 gap-4">
        <Link
          href="/medico/agenda"
          className="bg-card border border-border rounded-xl p-5 hover:border-primary/50 hover:shadow-sm transition-all group"
        >
          <div className="w-12 h-12 bg-chart-1/10 rounded-xl flex items-center justify-center mb-4">
            <Calendar className="w-6 h-6 text-chart-1" />
          </div>
          <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
            Mi Agenda
          </h3>
          <p className="text-sm text-muted-foreground mt-1">
            Gestiona tus citas y horarios
          </p>
        </Link>

        <Link
          href="/medico/pacientes"
          className="bg-card border border-border rounded-xl p-5 hover:border-primary/50 hover:shadow-sm transition-all group"
        >
          <div className="w-12 h-12 bg-chart-2/10 rounded-xl flex items-center justify-center mb-4">
            <Users className="w-6 h-6 text-chart-2" />
          </div>
          <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
            Mis Pacientes
          </h3>
          <p className="text-sm text-muted-foreground mt-1">
            Historiales y seguimiento
          </p>
        </Link>

        <Link
          href="/medico/ordenes"
          className="bg-card border border-border rounded-xl p-5 hover:border-primary/50 hover:shadow-sm transition-all group"
        >
          <div className="w-12 h-12 bg-chart-3/10 rounded-xl flex items-center justify-center mb-4">
            <FileText className="w-6 h-6 text-chart-3" />
          </div>
          <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
            Ordenes Medicas
          </h3>
          <p className="text-sm text-muted-foreground mt-1">
            Formulas y autorizaciones
          </p>
        </Link>
      </div>
    </div>
  )
}
