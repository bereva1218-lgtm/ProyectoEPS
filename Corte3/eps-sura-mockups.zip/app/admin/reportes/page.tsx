"use client"

import { useState } from "react"
import { 
  BarChart3, 
  Download,
  Calendar,
  TrendingUp,
  Users,
  FileCheck,
  Building2,
  Activity,
  Clock,
  Filter
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const reportTypes = [
  {
    id: "citas",
    name: "Reporte de Citas",
    description: "Análisis de citas médicas por período, especialidad e IPS",
    icon: Calendar,
    lastGenerated: "2024-02-15"
  },
  {
    id: "autorizaciones",
    name: "Reporte de Autorizaciones",
    description: "Estado y tiempos de respuesta de autorizaciones médicas",
    icon: FileCheck,
    lastGenerated: "2024-02-15"
  },
  {
    id: "afiliados",
    name: "Reporte de Afiliados",
    description: "Demografía y movimiento de afiliados",
    icon: Users,
    lastGenerated: "2024-02-14"
  },
  {
    id: "ips",
    name: "Reporte de Red IPS",
    description: "Utilización y desempeño de la red de IPS",
    icon: Building2,
    lastGenerated: "2024-02-14"
  }
]

const kpiData = {
  citas: {
    total: 8542,
    change: "+12.3%",
    trend: "up",
    breakdown: [
      { label: "Medicina General", value: 3250, percentage: 38 },
      { label: "Pediatría", value: 1852, percentage: 22 },
      { label: "Cardiología", value: 1024, percentage: 12 },
      { label: "Ginecología", value: 892, percentage: 10 },
      { label: "Otras", value: 1524, percentage: 18 }
    ]
  },
  autorizaciones: {
    total: 1256,
    aprobadas: 892,
    rechazadas: 124,
    pendientes: 240,
    tiempoPromedio: "2.3 días"
  },
  afiliados: {
    total: 125847,
    nuevos: 1523,
    retirados: 287,
    activos: 118924
  }
}

const monthlyData = [
  { month: "Ene", citas: 7200, autorizaciones: 980, nuevosAfiliados: 1200 },
  { month: "Feb", citas: 8542, autorizaciones: 1256, nuevosAfiliados: 1523 },
  { month: "Mar", citas: 0, autorizaciones: 0, nuevosAfiliados: 0 },
  { month: "Abr", citas: 0, autorizaciones: 0, nuevosAfiliados: 0 }
]

export default function ReportesPage() {
  const [period, setPeriod] = useState("month")
  const [activeReport, setActiveReport] = useState("citas")

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Reportes y Estadísticas</h1>
          <p className="text-muted-foreground">Análisis de indicadores clave del sistema de salud</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Esta semana</SelectItem>
              <SelectItem value="month">Este mes</SelectItem>
              <SelectItem value="quarter">Este trimestre</SelectItem>
              <SelectItem value="year">Este año</SelectItem>
            </SelectContent>
          </Select>
          <Button>
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Report Types */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {reportTypes.map((report) => (
          <Card 
            key={report.id}
            className={`cursor-pointer transition-all hover:shadow-md ${
              activeReport === report.id ? "ring-2 ring-primary" : ""
            }`}
            onClick={() => setActiveReport(report.id)}
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-lg ${
                  activeReport === report.id ? "bg-primary text-primary-foreground" : "bg-muted"
                }`}>
                  <report.icon className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{report.name}</p>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{report.description}</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Último: {report.lastGenerated}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Report Content */}
      <Tabs value={activeReport} onValueChange={setActiveReport}>
        <TabsContent value="citas" className="m-0 space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Citas</p>
                    <p className="text-3xl font-bold">{kpiData.citas.total.toLocaleString()}</p>
                    <div className="flex items-center gap-1 text-success text-sm mt-1">
                      <TrendingUp className="h-4 w-4" />
                      <span>{kpiData.citas.change} vs mes anterior</span>
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-primary/10">
                    <Calendar className="h-8 w-8 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Tasa de Asistencia</p>
                    <p className="text-3xl font-bold">87.5%</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      12.5% no asistencia
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-success/10">
                    <Activity className="h-8 w-8 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Tiempo Espera Prom.</p>
                    <p className="text-3xl font-bold">4.2 días</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Para obtener cita
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-warning/10">
                    <Clock className="h-8 w-8 text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Distribución por Especialidad
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {kpiData.citas.breakdown.map((item) => (
                  <div key={item.label}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{item.label}</span>
                      <span className="text-sm text-muted-foreground">
                        {item.value.toLocaleString()} ({item.percentage}%)
                      </span>
                    </div>
                    <div className="h-3 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary rounded-full transition-all"
                        style={{ width: `${item.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Monthly Trend */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Tendencia Mensual
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] flex items-end justify-between gap-4">
                {monthlyData.map((data, index) => (
                  <div key={data.month} className="flex-1 flex flex-col items-center">
                    <div 
                      className={`w-full rounded-t-lg transition-all ${
                        data.citas > 0 ? "bg-primary" : "bg-muted"
                      }`}
                      style={{ 
                        height: `${data.citas > 0 ? (data.citas / 10000) * 150 : 20}px`,
                        minHeight: "20px"
                      }}
                    />
                    <span className="text-sm text-muted-foreground mt-2">{data.month}</span>
                    {data.citas > 0 && (
                      <span className="text-xs font-medium">{data.citas.toLocaleString()}</span>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="autorizaciones" className="m-0 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold text-foreground">{kpiData.autorizaciones.total}</p>
                <p className="text-sm text-muted-foreground">Total Solicitudes</p>
              </CardContent>
            </Card>
            <Card className="border-success/30">
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold text-success">{kpiData.autorizaciones.aprobadas}</p>
                <p className="text-sm text-muted-foreground">Aprobadas</p>
                <Badge variant="secondary" className="mt-2 bg-success/10 text-success">
                  {Math.round((kpiData.autorizaciones.aprobadas / kpiData.autorizaciones.total) * 100)}%
                </Badge>
              </CardContent>
            </Card>
            <Card className="border-destructive/30">
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold text-destructive">{kpiData.autorizaciones.rechazadas}</p>
                <p className="text-sm text-muted-foreground">Rechazadas</p>
                <Badge variant="secondary" className="mt-2 bg-destructive/10 text-destructive">
                  {Math.round((kpiData.autorizaciones.rechazadas / kpiData.autorizaciones.total) * 100)}%
                </Badge>
              </CardContent>
            </Card>
            <Card className="border-warning/30">
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold text-warning">{kpiData.autorizaciones.pendientes}</p>
                <p className="text-sm text-muted-foreground">Pendientes</p>
                <Badge variant="secondary" className="mt-2 bg-warning/10 text-warning-foreground">
                  {Math.round((kpiData.autorizaciones.pendientes / kpiData.autorizaciones.total) * 100)}%
                </Badge>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Tiempo Promedio de Respuesta</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center py-8">
                <div className="text-center">
                  <p className="text-5xl font-bold text-primary">{kpiData.autorizaciones.tiempoPromedio}</p>
                  <p className="text-muted-foreground mt-2">Tiempo promedio de resolución</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="afiliados" className="m-0 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold">{kpiData.afiliados.total.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Total Afiliados</p>
              </CardContent>
            </Card>
            <Card className="border-success/30">
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold text-success">{kpiData.afiliados.activos.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Activos</p>
              </CardContent>
            </Card>
            <Card className="border-primary/30">
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold text-primary">+{kpiData.afiliados.nuevos.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Nuevos este mes</p>
              </CardContent>
            </Card>
            <Card className="border-destructive/30">
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold text-destructive">-{kpiData.afiliados.retirados}</p>
                <p className="text-sm text-muted-foreground">Retirados este mes</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Crecimiento Neto</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center py-8">
                <div className="text-center">
                  <p className="text-5xl font-bold text-success">
                    +{(kpiData.afiliados.nuevos - kpiData.afiliados.retirados).toLocaleString()}
                  </p>
                  <p className="text-muted-foreground mt-2">Crecimiento neto este mes</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ips" className="m-0 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold">45</p>
                <p className="text-sm text-muted-foreground">IPS en la red</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold">160</p>
                <p className="text-sm text-muted-foreground">Médicos activos</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-3xl font-bold">28</p>
                <p className="text-sm text-muted-foreground">Especialidades disponibles</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Utilización por IPS</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: "IPS Centro Médico Norte", utilization: 92 },
                  { name: "Clínica del Sur", utilization: 87 },
                  { name: "Centro de Diagnóstico Oriente", utilization: 78 },
                  { name: "IPS Salud Integral Occidente", utilization: 45 }
                ].map((ips) => (
                  <div key={ips.name}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{ips.name}</span>
                      <span className="text-sm text-muted-foreground">{ips.utilization}%</span>
                    </div>
                    <div className="h-3 bg-muted rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all ${
                          ips.utilization > 80 ? "bg-success" : 
                          ips.utilization > 60 ? "bg-primary" : 
                          "bg-warning"
                        }`}
                        style={{ width: `${ips.utilization}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
