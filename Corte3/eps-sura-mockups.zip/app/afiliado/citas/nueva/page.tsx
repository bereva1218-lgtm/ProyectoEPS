'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { especialidades, sedes, usuarios } from '@/lib/mock-data'
import {
  ArrowLeft,
  Calendar,
  Clock,
  MapPin,
  User,
  Search,
  ChevronRight,
  Video,
  Building2,
  CheckCircle2
} from 'lucide-react'

type Step = 'especialidad' | 'medico' | 'fecha' | 'confirmacion'

export default function NuevaCitaPage() {
  const router = useRouter()
  const [step, setStep] = useState<Step>('especialidad')
  const [selectedEspecialidad, setSelectedEspecialidad] = useState('')
  const [selectedMedico, setSelectedMedico] = useState<typeof usuarios[0] | null>(null)
  const [selectedSede, setSelectedSede] = useState('')
  const [selectedFecha, setSelectedFecha] = useState('')
  const [selectedHora, setSelectedHora] = useState('')
  const [tipoCita, setTipoCita] = useState<'presencial' | 'virtual'>('presencial')
  const [motivo, setMotivo] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isComplete, setIsComplete] = useState(false)

  const medicos = usuarios.filter(u => u.rol === 'medico')
  const filteredMedicos = medicos.filter(m => 
    !selectedEspecialidad || m.especialidad === selectedEspecialidad
  )

  const filteredEspecialidades = especialidades.filter(e =>
    e.toLowerCase().includes(searchQuery.toLowerCase())
  )

  // Generate available dates (next 14 days)
  const availableDates = Array.from({ length: 14 }, (_, i) => {
    const date = new Date()
    date.setDate(date.getDate() + i + 1)
    return date.toISOString().split('T')[0]
  })

  // Generate available times
  const availableTimes = [
    '07:00', '07:30', '08:00', '08:30', '09:00', '09:30',
    '10:00', '10:30', '11:00', '11:30', '14:00', '14:30',
    '15:00', '15:30', '16:00', '16:30', '17:00'
  ]

  const handleSubmit = async () => {
    setIsSubmitting(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    setIsComplete(true)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('es-CO', { 
      weekday: 'long', 
      day: 'numeric', 
      month: 'long' 
    })
  }

  if (isComplete) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-card border border-border rounded-2xl p-8 text-center">
          <div className="w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-success" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">Cita agendada exitosamente</h1>
          <p className="text-muted-foreground mb-6">
            Tu cita ha sido programada. Recibiras una notificacion de confirmacion.
          </p>
          
          <div className="bg-muted/50 rounded-xl p-4 mb-6 text-left">
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Especialidad:</span>
                <span className="font-medium text-foreground">{selectedEspecialidad}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Medico:</span>
                <span className="font-medium text-foreground">{selectedMedico?.nombre} {selectedMedico?.apellido}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fecha:</span>
                <span className="font-medium text-foreground">{formatDate(selectedFecha)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Hora:</span>
                <span className="font-medium text-foreground">{selectedHora}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tipo:</span>
                <span className="font-medium text-foreground capitalize">{tipoCita}</span>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Link
              href="/afiliado/citas"
              className="flex-1 px-4 py-2.5 bg-muted text-foreground rounded-xl font-medium hover:bg-muted/80 transition-colors"
            >
              Ver mis citas
            </Link>
            <Link
              href="/afiliado"
              className="flex-1 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors"
            >
              Ir al inicio
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => {
            if (step === 'especialidad') router.push('/afiliado/citas')
            else if (step === 'medico') setStep('especialidad')
            else if (step === 'fecha') setStep('medico')
            else if (step === 'confirmacion') setStep('fecha')
          }}
          className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Agendar nueva cita</h1>
          <p className="text-muted-foreground">
            {step === 'especialidad' && 'Selecciona una especialidad'}
            {step === 'medico' && 'Elige tu medico'}
            {step === 'fecha' && 'Selecciona fecha y hora'}
            {step === 'confirmacion' && 'Confirma tu cita'}
          </p>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center gap-2 mb-8">
        {['especialidad', 'medico', 'fecha', 'confirmacion'].map((s, idx) => (
          <div key={s} className="flex items-center flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
              step === s 
                ? 'bg-primary text-primary-foreground' 
                : ['especialidad', 'medico', 'fecha', 'confirmacion'].indexOf(step) > idx
                  ? 'bg-success text-success-foreground'
                  : 'bg-muted text-muted-foreground'
            }`}>
              {idx + 1}
            </div>
            {idx < 3 && (
              <div className={`flex-1 h-1 mx-2 rounded ${
                ['especialidad', 'medico', 'fecha', 'confirmacion'].indexOf(step) > idx
                  ? 'bg-success'
                  : 'bg-muted'
              }`} />
            )}
          </div>
        ))}
      </div>

      {/* Step Content */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        {/* Step 1: Especialidad */}
        {step === 'especialidad' && (
          <div className="p-6">
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Buscar especialidad..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-muted border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto">
              {filteredEspecialidades.map((esp) => (
                <button
                  key={esp}
                  onClick={() => {
                    setSelectedEspecialidad(esp)
                    setStep('medico')
                  }}
                  className={`p-4 rounded-xl text-left border transition-colors ${
                    selectedEspecialidad === esp
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-primary/50 hover:bg-muted'
                  }`}
                >
                  <span className="font-medium text-foreground">{esp}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Medico */}
        {step === 'medico' && (
          <div className="p-6">
            <div className="mb-4 p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">Especialidad seleccionada:</p>
              <p className="font-medium text-foreground">{selectedEspecialidad}</p>
            </div>

            <div className="space-y-3">
              {filteredMedicos.length > 0 ? (
                filteredMedicos.map((medico) => (
                  <button
                    key={medico.id}
                    onClick={() => {
                      setSelectedMedico(medico)
                      setStep('fecha')
                    }}
                    className={`w-full p-4 rounded-xl text-left border transition-colors flex items-center gap-4 ${
                      selectedMedico?.id === medico.id
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50 hover:bg-muted'
                    }`}
                  >
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <User className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{medico.nombre} {medico.apellido}</p>
                      <p className="text-sm text-muted-foreground">{medico.especialidad}</p>
                      <p className="text-sm text-muted-foreground">{medico.consultorio}</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground" />
                  </button>
                ))
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  No hay medicos disponibles para esta especialidad
                </p>
              )}
            </div>
          </div>
        )}

        {/* Step 3: Fecha y Hora */}
        {step === 'fecha' && (
          <div className="p-6 space-y-6">
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">Medico seleccionado:</p>
              <p className="font-medium text-foreground">{selectedMedico?.nombre} {selectedMedico?.apellido} - {selectedEspecialidad}</p>
            </div>

            {/* Tipo de cita */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">Tipo de consulta</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setTipoCita('presencial')}
                  className={`p-4 rounded-xl border flex items-center gap-3 transition-colors ${
                    tipoCita === 'presencial'
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-primary/50'
                  }`}
                >
                  <Building2 className={`w-5 h-5 ${tipoCita === 'presencial' ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className="font-medium text-foreground">Presencial</span>
                </button>
                <button
                  onClick={() => setTipoCita('virtual')}
                  className={`p-4 rounded-xl border flex items-center gap-3 transition-colors ${
                    tipoCita === 'virtual'
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-primary/50'
                  }`}
                >
                  <Video className={`w-5 h-5 ${tipoCita === 'virtual' ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className="font-medium text-foreground">Virtual</span>
                </button>
              </div>
            </div>

            {/* Sede (solo si es presencial) */}
            {tipoCita === 'presencial' && (
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">Sede</label>
                <select
                  value={selectedSede}
                  onChange={(e) => setSelectedSede(e.target.value)}
                  className="w-full p-3 bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="">Selecciona una sede</option>
                  {sedes.map((sede) => (
                    <option key={sede.id} value={sede.id}>
                      {sede.nombre} - {sede.direccion}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Fecha */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">Fecha disponible</label>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {availableDates.slice(0, 7).map((date) => (
                  <button
                    key={date}
                    onClick={() => setSelectedFecha(date)}
                    className={`flex-shrink-0 w-20 p-3 rounded-xl border text-center transition-colors ${
                      selectedFecha === date
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <span className="block text-xs text-muted-foreground uppercase">
                      {new Date(date).toLocaleDateString('es-CO', { weekday: 'short' })}
                    </span>
                    <span className="block text-lg font-bold text-foreground">
                      {new Date(date).getDate()}
                    </span>
                    <span className="block text-xs text-muted-foreground">
                      {new Date(date).toLocaleDateString('es-CO', { month: 'short' })}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Hora */}
            {selectedFecha && (
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">Hora disponible</label>
                <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                  {availableTimes.map((time) => (
                    <button
                      key={time}
                      onClick={() => setSelectedHora(time)}
                      className={`p-2 rounded-lg border text-sm font-medium transition-colors ${
                        selectedHora === time
                          ? 'border-primary bg-primary text-primary-foreground'
                          : 'border-border hover:border-primary/50 text-foreground'
                      }`}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Motivo */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Motivo de la consulta (opcional)</label>
              <textarea
                value={motivo}
                onChange={(e) => setMotivo(e.target.value)}
                placeholder="Describe brevemente el motivo de tu consulta..."
                rows={3}
                className="w-full p-3 bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring resize-none"
              />
            </div>

            {/* Continue Button */}
            <button
              onClick={() => setStep('confirmacion')}
              disabled={!selectedFecha || !selectedHora || (tipoCita === 'presencial' && !selectedSede)}
              className="w-full py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Continuar
            </button>
          </div>
        )}

        {/* Step 4: Confirmacion */}
        {step === 'confirmacion' && (
          <div className="p-6 space-y-6">
            <h2 className="font-semibold text-lg text-foreground">Resumen de tu cita</h2>
            
            <div className="space-y-4">
              <div className="flex items-start gap-4 p-4 bg-muted/50 rounded-xl">
                <Calendar className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <p className="font-medium text-foreground">{formatDate(selectedFecha)}</p>
                  <p className="text-sm text-muted-foreground">{selectedHora}</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-muted/50 rounded-xl">
                <User className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <p className="font-medium text-foreground">{selectedMedico?.nombre} {selectedMedico?.apellido}</p>
                  <p className="text-sm text-muted-foreground">{selectedEspecialidad}</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-muted/50 rounded-xl">
                {tipoCita === 'presencial' ? (
                  <>
                    <MapPin className="w-5 h-5 text-primary mt-0.5" />
                    <div>
                      <p className="font-medium text-foreground">Consulta presencial</p>
                      <p className="text-sm text-muted-foreground">
                        {sedes.find(s => s.id === selectedSede)?.nombre} - {sedes.find(s => s.id === selectedSede)?.direccion}
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <Video className="w-5 h-5 text-primary mt-0.5" />
                    <div>
                      <p className="font-medium text-foreground">Consulta virtual</p>
                      <p className="text-sm text-muted-foreground">Recibiras el enlace por correo electronico</p>
                    </div>
                  </>
                )}
              </div>

              {motivo && (
                <div className="p-4 bg-muted/50 rounded-xl">
                  <p className="text-sm text-muted-foreground mb-1">Motivo:</p>
                  <p className="text-foreground">{motivo}</p>
                </div>
              )}
            </div>

            <div className="bg-warning/10 border border-warning/20 rounded-xl p-4">
              <p className="text-sm text-foreground">
                Al confirmar, aceptas asistir a la cita en la fecha y hora indicadas. 
                Si no puedes asistir, por favor cancela con al menos 24 horas de anticipacion.
              </p>
            </div>

            <button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="w-full py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isSubmitting ? 'Agendando...' : 'Confirmar cita'}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
