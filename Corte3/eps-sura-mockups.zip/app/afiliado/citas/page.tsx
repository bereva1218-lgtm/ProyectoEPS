'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useAuth } from '@/lib/auth-context'
import { citas } from '@/lib/mock-data'
import {
  Calendar,
  Clock,
  MapPin,
  User,
  Plus,
  Filter,
  ChevronLeft,
  ChevronRight,
  Video,
  Building2,
  X,
  CheckCircle2,
  XCircle,
  AlertCircle
} from 'lucide-react'

export default function CitasPage() {
  const { user } = useAuth()
  const [filter, setFilter] = useState<'todas' | 'programadas' | 'completadas' | 'canceladas'>('todas')
  const [showCancelModal, setShowCancelModal] = useState<string | null>(null)

  const userCitas = citas.filter(c => c.pacienteId === user?.id)
  
  const filteredCitas = userCitas.filter(c => {
    if (filter === 'todas') return true
    if (filter === 'programadas') return c.estado === 'programada' || c.estado === 'confirmada'
    if (filter === 'completadas') return c.estado === 'completada'
    if (filter === 'canceladas') return c.estado === 'cancelada' || c.estado === 'no_asistio'
    return true
  })

  const proximasCitas = filteredCitas.filter(c => 
    c.estado === 'programada' || c.estado === 'confirmada'
  )
  const citasPasadas = filteredCitas.filter(c => 
    c.estado === 'completada' || c.estado === 'cancelada' || c.estado === 'no_asistio'
  )

  const getStatusBadge = (estado: string) => {
    const styles: Record<string, string> = {
      'programada': 'bg-warning/10 text-warning',
      'confirmada': 'bg-success/10 text-success',
      'en_curso': 'bg-chart-3/10 text-chart-3',
      'completada': 'bg-muted text-muted-foreground',
      'cancelada': 'bg-destructive/10 text-destructive',
      'no_asistio': 'bg-destructive/10 text-destructive',
    }
    const labels: Record<string, string> = {
      'programada': 'Por confirmar',
      'confirmada': 'Confirmada',
      'en_curso': 'En curso',
      'completada': 'Completada',
      'cancelada': 'Cancelada',
      'no_asistio': 'No asistio',
    }
    return (
      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${styles[estado] || 'bg-muted text-muted-foreground'}`}>
        {labels[estado] || estado}
      </span>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Mis Citas</h1>
          <p className="text-muted-foreground mt-1">Gestiona tus citas medicas</p>
        </div>
        <Link
          href="/afiliado/citas/nueva"
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Agendar cita
        </Link>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {[
          { value: 'todas', label: 'Todas' },
          { value: 'programadas', label: 'Proximas' },
          { value: 'completadas', label: 'Completadas' },
          { value: 'canceladas', label: 'Canceladas' },
        ].map((f) => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value as typeof filter)}
            className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
              filter === f.value
                ? 'bg-primary text-primary-foreground'
                : 'bg-card border border-border text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Upcoming Appointments */}
      {proximasCitas.length > 0 && (
        <div className="space-y-4">
          <h2 className="font-semibold text-lg text-foreground">Proximas citas</h2>
          <div className="grid gap-4">
            {proximasCitas.map((cita) => (
              <div
                key={cita.id}
                className="bg-card border border-border rounded-2xl p-5 hover:border-primary/30 transition-colors"
              >
                <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                  {/* Date */}
                  <div className="flex items-center gap-4 lg:w-36 flex-shrink-0">
                    <div className="w-14 h-14 bg-primary/10 rounded-xl flex flex-col items-center justify-center">
                      <span className="text-xl font-bold text-primary">
                        {new Date(cita.fecha).getDate()}
                      </span>
                      <span className="text-xs text-primary uppercase">
                        {new Date(cita.fecha).toLocaleDateString('es-CO', { month: 'short' })}
                      </span>
                    </div>
                    <div className="lg:hidden">
                      <p className="font-semibold text-foreground">{cita.especialidad}</p>
                      <p className="text-sm text-muted-foreground">{cita.medicoNombre}</p>
                    </div>
                  </div>

                  {/* Details */}
                  <div className="flex-1 space-y-2">
                    <div className="hidden lg:block">
                      <p className="font-semibold text-foreground">{cita.especialidad}</p>
                      <p className="text-sm text-muted-foreground">{cita.medicoNombre}</p>
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1.5">
                        <Clock className="w-4 h-4" />
                        {cita.hora}
                      </span>
                      <span className="flex items-center gap-1.5">
                        {cita.tipo === 'presencial' ? (
                          <>
                            <Building2 className="w-4 h-4" />
                            {cita.consultorio}
                          </>
                        ) : (
                          <>
                            <Video className="w-4 h-4" />
                            Consulta virtual
                          </>
                        )}
                      </span>
                    </div>

                    {cita.motivo && (
                      <p className="text-sm text-muted-foreground">
                        <span className="font-medium">Motivo:</span> {cita.motivo}
                      </p>
                    )}
                  </div>

                  {/* Status & Actions */}
                  <div className="flex items-center gap-3 lg:flex-col lg:items-end">
                    {getStatusBadge(cita.estado)}
                    <div className="flex gap-2">
                      {cita.tipo === 'virtual' && cita.estado === 'confirmada' && (
                        <button className="px-3 py-1.5 bg-chart-3 text-white rounded-lg text-sm font-medium hover:bg-chart-3/90 transition-colors">
                          Unirse
                        </button>
                      )}
                      <button
                        onClick={() => setShowCancelModal(cita.id)}
                        className="px-3 py-1.5 bg-muted text-muted-foreground rounded-lg text-sm font-medium hover:bg-destructive/10 hover:text-destructive transition-colors"
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Past Appointments */}
      {citasPasadas.length > 0 && (
        <div className="space-y-4">
          <h2 className="font-semibold text-lg text-foreground">Historial de citas</h2>
          <div className="grid gap-3">
            {citasPasadas.map((cita) => (
              <div
                key={cita.id}
                className="bg-card border border-border rounded-xl p-4 opacity-75"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-muted rounded-lg flex flex-col items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold text-muted-foreground">
                      {new Date(cita.fecha).getDate()}
                    </span>
                    <span className="text-xs text-muted-foreground uppercase">
                      {new Date(cita.fecha).toLocaleDateString('es-CO', { month: 'short' })}
                    </span>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground">{cita.especialidad}</p>
                    <p className="text-sm text-muted-foreground">{cita.medicoNombre}</p>
                  </div>

                  {getStatusBadge(cita.estado)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {filteredCitas.length === 0 && (
        <div className="bg-card border border-border rounded-2xl p-12 text-center">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Calendar className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="font-semibold text-lg text-foreground mb-2">No hay citas</h3>
          <p className="text-muted-foreground mb-6">
            No se encontraron citas con el filtro seleccionado
          </p>
          <Link
            href="/afiliado/citas/nueva"
            className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Agendar nueva cita
          </Link>
        </div>
      )}

      {/* Cancel Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-foreground/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-2xl p-6 max-w-md w-full shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg text-foreground">Cancelar cita</h3>
              <button
                onClick={() => setShowCancelModal(null)}
                className="p-1 text-muted-foreground hover:text-foreground rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-muted-foreground mb-6">
              ¿Esta seguro que desea cancelar esta cita? Esta accion no se puede deshacer.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowCancelModal(null)}
                className="flex-1 px-4 py-2.5 bg-muted text-foreground rounded-xl font-medium hover:bg-muted/80 transition-colors"
              >
                No, mantener
              </button>
              <button
                onClick={() => {
                  // In production, this would call an API
                  setShowCancelModal(null)
                }}
                className="flex-1 px-4 py-2.5 bg-destructive text-destructive-foreground rounded-xl font-medium hover:bg-destructive/90 transition-colors"
              >
                Si, cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
