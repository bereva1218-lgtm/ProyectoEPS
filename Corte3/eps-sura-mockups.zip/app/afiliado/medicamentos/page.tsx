'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { medicamentos } from '@/lib/mock-data'
import {
  Pill,
  Clock,
  Calendar,
  User,
  AlertCircle,
  CheckCircle2,
  MapPin,
  Info,
  ChevronDown,
  ChevronUp,
  Printer,
  Search
} from 'lucide-react'

export default function MedicamentosPage() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState<'activos' | 'historial'>('activos')
  const [expandedItems, setExpandedItems] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState('')

  const userMedicamentos = medicamentos
  const activeMeds = userMedicamentos.filter(m => m.estado === 'activo')
  const historialMeds = userMedicamentos.filter(m => m.estado !== 'activo')

  const displayMeds = activeTab === 'activos' ? activeMeds : historialMeds

  const filteredMeds = displayMeds.filter(m =>
    m.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.principioActivo.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const toggleExpand = (id: string) => {
    setExpandedItems(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  const totalPendientes = activeMeds.reduce((acc, m) => acc + (m.reclamosPendientes || 0), 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Medicamentos</h1>
        <p className="text-muted-foreground mt-1">Gestiona tus formulas medicas y reclamos de medicamentos</p>
      </div>

      {/* Alert for pending claims */}
      {totalPendientes > 0 && (
        <div className="bg-accent/10 border border-accent/20 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-medium text-foreground">Tienes medicamentos pendientes por reclamar</p>
            <p className="text-sm text-muted-foreground mt-1">
              {totalPendientes} entrega(s) disponible(s) para recoger en la farmacia de tu sede mas cercana.
            </p>
          </div>
          <button className="text-primary text-sm font-medium hover:underline whitespace-nowrap">
            Ver farmacias
          </button>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-primary">{activeMeds.length}</p>
          <p className="text-sm text-muted-foreground">Medicamentos activos</p>
        </div>
        <div className="bg-card border border-accent/20 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-accent">{totalPendientes}</p>
          <p className="text-sm text-muted-foreground">Reclamos pendientes</p>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-foreground">{historialMeds.length}</p>
          <p className="text-sm text-muted-foreground">Formulas anteriores</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border">
        <button
          onClick={() => setActiveTab('activos')}
          className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
            activeTab === 'activos'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          Activos ({activeMeds.length})
        </button>
        <button
          onClick={() => setActiveTab('historial')}
          className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
            activeTab === 'historial'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          Historial ({historialMeds.length})
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          placeholder="Buscar medicamento..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-3 bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      {/* Medications List */}
      <div className="space-y-4">
        {filteredMeds.length > 0 ? (
          filteredMeds.map((med) => {
            const isExpanded = expandedItems.includes(med.id)
            const hasPending = (med.reclamosPendientes || 0) > 0

            return (
              <div
                key={med.id}
                className={`bg-card border rounded-2xl overflow-hidden ${
                  hasPending ? 'border-accent/30' : 'border-border'
                }`}
              >
                <button
                  onClick={() => toggleExpand(med.id)}
                  className="w-full p-5 flex items-start gap-4 text-left hover:bg-muted/50 transition-colors"
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    med.estado === 'activo' ? 'bg-primary/10' : 'bg-muted'
                  }`}>
                    <Pill className={`w-6 h-6 ${med.estado === 'activo' ? 'text-primary' : 'text-muted-foreground'}`} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="font-semibold text-foreground">{med.nombre}</p>
                        <p className="text-sm text-muted-foreground">{med.presentacion}</p>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {hasPending && (
                          <span className="px-2.5 py-1 bg-accent/10 text-accent text-xs font-medium rounded-full">
                            {med.reclamosPendientes} pendiente(s)
                          </span>
                        )}
                        {isExpanded ? (
                          <ChevronUp className="w-5 h-5 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-muted-foreground" />
                        )}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 mt-3 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1.5">
                        <Clock className="w-4 h-4" />
                        {med.frecuencia}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Calendar className="w-4 h-4" />
                        Hasta {med.fechaFin}
                      </span>
                    </div>
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-5 pb-5 pt-0 border-t border-border">
                    <div className="pt-4 space-y-4">
                      {/* Medication Details */}
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Principio activo</p>
                          <p className="font-medium text-foreground">{med.principioActivo}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Dosis</p>
                          <p className="font-medium text-foreground">{med.dosis}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Frecuencia</p>
                          <p className="font-medium text-foreground">{med.frecuencia}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Duracion</p>
                          <p className="font-medium text-foreground">{med.duracion}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Medico</p>
                          <p className="font-medium text-foreground">{med.medicoNombre}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Periodo</p>
                          <p className="font-medium text-foreground">{med.fechaInicio} - {med.fechaFin}</p>
                        </div>
                      </div>

                      {/* Instructions */}
                      {med.instrucciones && (
                        <div className="bg-muted/50 rounded-xl p-4">
                          <div className="flex items-start gap-2">
                            <Info className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                            <div>
                              <p className="text-sm font-medium text-foreground">Instrucciones</p>
                              <p className="text-sm text-muted-foreground mt-1">{med.instrucciones}</p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Pending Claims Info */}
                      {hasPending && (
                        <div className="bg-accent/10 border border-accent/20 rounded-xl p-4">
                          <div className="flex items-start gap-3">
                            <MapPin className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                            <div className="flex-1">
                              <p className="font-medium text-foreground">
                                {med.reclamosPendientes} entrega(s) disponible(s)
                              </p>
                              <p className="text-sm text-muted-foreground mt-1">
                                Puedes reclamar tu medicamento en cualquier farmacia de la red.
                                Presenta tu documento de identidad.
                              </p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex flex-wrap gap-3">
                        <button className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg text-sm font-medium hover:bg-muted/80 transition-colors">
                          <Printer className="w-4 h-4" />
                          Imprimir formula
                        </button>
                        {med.estado === 'activo' && (
                          <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                            <MapPin className="w-4 h-4" />
                            Ver farmacias cercanas
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )
          })
        ) : (
          <div className="bg-card border border-border rounded-2xl p-12 text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Pill className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-lg text-foreground mb-2">
              No hay medicamentos {activeTab === 'activos' ? 'activos' : 'en el historial'}
            </h3>
            <p className="text-muted-foreground">
              {searchQuery 
                ? 'No se encontraron medicamentos con ese nombre' 
                : activeTab === 'activos'
                  ? 'No tienes medicamentos formulados actualmente'
                  : 'No hay formulas anteriores registradas'}
            </p>
          </div>
        )}
      </div>

      {/* Pharmacies Info */}
      <div className="bg-card border border-border rounded-2xl p-6">
        <h3 className="font-semibold text-lg text-foreground mb-4">Farmacias de la red</h3>
        <div className="grid sm:grid-cols-2 gap-4">
          {[
            { nombre: 'Farmacia Sede Centro', direccion: 'Carrera 45 #52-12', horario: 'Lun-Vie: 7am-7pm, Sab: 8am-2pm' },
            { nombre: 'Farmacia Sede Poblado', direccion: 'Calle 10 #43-20', horario: 'Lun-Vie: 7am-8pm, Sab: 8am-4pm' },
          ].map((farmacia, idx) => (
            <div key={idx} className="p-4 bg-muted/50 rounded-xl">
              <p className="font-medium text-foreground">{farmacia.nombre}</p>
              <p className="text-sm text-muted-foreground mt-1">{farmacia.direccion}</p>
              <p className="text-sm text-muted-foreground">{farmacia.horario}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
