"use client"

import { useState } from "react"
import { 
  Users, 
  Search, 
  Filter,
  UserPlus,
  MoreVertical,
  Mail,
  Phone,
  Shield,
  UserCheck,
  UserX,
  Edit,
  Trash2,
  Eye
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"

const users = [
  {
    id: "1",
    name: "María García López",
    email: "maria.garcia@email.com",
    phone: "300 123 4567",
    document: "1.234.567.890",
    role: "afiliado",
    status: "activo",
    registeredAt: "2023-01-15",
    lastLogin: "2024-02-15"
  },
  {
    id: "2",
    name: "Dr. Carlos Mendoza",
    email: "carlos.mendoza@eps.com",
    phone: "301 234 5678",
    document: "9.876.543.210",
    role: "medico",
    status: "activo",
    registeredAt: "2022-06-10",
    lastLogin: "2024-02-15"
  },
  {
    id: "3",
    name: "Ana Rodríguez",
    email: "ana.rodriguez@eps.com",
    phone: "302 345 6789",
    document: "5.555.666.777",
    role: "admin",
    status: "activo",
    registeredAt: "2021-03-20",
    lastLogin: "2024-02-15"
  },
  {
    id: "4",
    name: "Pedro Sánchez",
    email: "pedro.sanchez@email.com",
    phone: "303 456 7890",
    document: "1.111.222.333",
    role: "afiliado",
    status: "inactivo",
    registeredAt: "2023-08-05",
    lastLogin: "2024-01-10"
  },
  {
    id: "5",
    name: "Dra. Laura Gómez",
    email: "laura.gomez@eps.com",
    phone: "304 567 8901",
    document: "4.444.555.666",
    role: "medico",
    status: "activo",
    registeredAt: "2022-11-15",
    lastLogin: "2024-02-14"
  }
]

const roleConfig = {
  afiliado: { label: "Afiliado", color: "bg-primary/10 text-primary border-primary/30", icon: Users },
  medico: { label: "Médico", color: "bg-accent/10 text-accent border-accent/30", icon: UserCheck },
  admin: { label: "Admin", color: "bg-warning/10 text-warning-foreground border-warning/30", icon: Shield }
}

const statusConfig = {
  activo: { label: "Activo", color: "bg-success/10 text-success border-success/30" },
  inactivo: { label: "Inactivo", color: "bg-muted text-muted-foreground" }
}

export default function UsuariosPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [roleFilter, setRoleFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [isNewUserOpen, setIsNewUserOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("all")

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.document.includes(searchTerm)
    const matchesRole = roleFilter === "all" || user.role === roleFilter
    const matchesStatus = statusFilter === "all" || user.status === statusFilter
    const matchesTab = activeTab === "all" || user.role === activeTab
    return matchesSearch && matchesRole && matchesStatus && matchesTab
  })

  const userStats = {
    total: users.length,
    afiliados: users.filter(u => u.role === "afiliado").length,
    medicos: users.filter(u => u.role === "medico").length,
    admins: users.filter(u => u.role === "admin").length,
    activos: users.filter(u => u.status === "activo").length
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Gestión de Usuarios</h1>
          <p className="text-muted-foreground">Administre afiliados, médicos y personal administrativo</p>
        </div>
        <Dialog open={isNewUserOpen} onOpenChange={setIsNewUserOpen}>
          <DialogTrigger asChild>
            <Button size="lg">
              <UserPlus className="h-5 w-5 mr-2" />
              Nuevo Usuario
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Registrar Nuevo Usuario</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <Label>Nombre completo</Label>
                <Input placeholder="Nombre y apellidos" className="mt-1" />
              </div>
              <div>
                <Label>Documento de identidad</Label>
                <Input placeholder="Número de cédula" className="mt-1" />
              </div>
              <div>
                <Label>Correo electrónico</Label>
                <Input type="email" placeholder="correo@ejemplo.com" className="mt-1" />
              </div>
              <div>
                <Label>Teléfono</Label>
                <Input placeholder="300 000 0000" className="mt-1" />
              </div>
              <div>
                <Label>Tipo de usuario</Label>
                <Select>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Seleccionar rol" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="afiliado">Afiliado</SelectItem>
                    <SelectItem value="medico">Médico</SelectItem>
                    <SelectItem value="admin">Administrador</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2 pt-4">
                <Button variant="outline" className="flex-1" onClick={() => setIsNewUserOpen(false)}>
                  Cancelar
                </Button>
                <Button className="flex-1" onClick={() => setIsNewUserOpen(false)}>
                  Registrar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{userStats.total}</p>
                <p className="text-sm text-muted-foreground">Total</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{userStats.afiliados}</p>
                <p className="text-sm text-muted-foreground">Afiliados</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/10">
                <UserCheck className="h-5 w-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{userStats.medicos}</p>
                <p className="text-sm text-muted-foreground">Médicos</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-warning/10">
                <Shield className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{userStats.admins}</p>
                <p className="text-sm text-muted-foreground">Admins</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10">
                <UserCheck className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{userStats.activos}</p>
                <p className="text-sm text-muted-foreground">Activos</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs and Filters */}
      <Card>
        <CardContent className="p-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
              <TabsList>
                <TabsTrigger value="all">Todos</TabsTrigger>
                <TabsTrigger value="afiliado">Afiliados</TabsTrigger>
                <TabsTrigger value="medico">Médicos</TabsTrigger>
                <TabsTrigger value="admin">Admins</TabsTrigger>
              </TabsList>
              <div className="flex gap-2">
                <div className="relative flex-1 md:w-[300px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por nombre, email o documento..."
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[140px]">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="activo">Activos</SelectItem>
                    <SelectItem value="inactivo">Inactivos</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <TabsContent value={activeTab} className="m-0">
              <div className="space-y-3">
                {filteredUsers.map((user) => {
                  const roleInfo = roleConfig[user.role as keyof typeof roleConfig]
                  const statusInfo = statusConfig[user.status as keyof typeof statusConfig]
                  const RoleIcon = roleInfo.icon

                  return (
                    <div 
                      key={user.id}
                      className="flex flex-col md:flex-row md:items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors gap-4"
                    >
                      <div className="flex items-center gap-4">
                        <Avatar className="h-12 w-12">
                          <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                            {user.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold">{user.name}</span>
                            <Badge variant="outline" className={roleInfo.color}>
                              <RoleIcon className="h-3 w-3 mr-1" />
                              {roleInfo.label}
                            </Badge>
                            <Badge variant="outline" className={statusInfo.color}>
                              {statusInfo.label}
                            </Badge>
                          </div>
                          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Mail className="h-3 w-3" />
                              {user.email}
                            </span>
                            <span className="flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              {user.phone}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            CC: {user.document} | Último acceso: {user.lastLogin}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-auto">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4 mr-1" />
                          Ver perfil
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Edit className="h-4 w-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Mail className="h-4 w-4 mr-2" />
                              Enviar correo
                            </DropdownMenuItem>
                            {user.status === "activo" ? (
                              <DropdownMenuItem>
                                <UserX className="h-4 w-4 mr-2" />
                                Desactivar
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem>
                                <UserCheck className="h-4 w-4 mr-2" />
                                Activar
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="h-4 w-4 mr-2" />
                              Eliminar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  )
                })}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {filteredUsers.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-lg font-medium text-muted-foreground">No se encontraron usuarios</p>
            <p className="text-sm text-muted-foreground">Intente ajustar los filtros de búsqueda</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
