'use client'

import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react'
import type { User, UserRole } from './types'
import { usuarios } from './mock-data'

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  logout: () => void
  switchRole: (role: UserRole) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simular verificacion de sesion existente
    setIsLoading(false)
  }, [])

  const login = useCallback(async (email: string, _password: string): Promise<{ success: boolean; error?: string }> => {
    // Simulacion de autenticacion - en produccion usar backend real
    await new Promise(resolve => setTimeout(resolve, 800))
    
    const foundUser = usuarios.find(u => u.email.toLowerCase() === email.toLowerCase())
    
    if (foundUser) {
      setUser(foundUser)
      return { success: true }
    }
    
    return { success: false, error: 'Credenciales invalidas. Intente con: maria.garcia@email.com, carlos.rodriguez@eps.com o admin@eps.com' }
  }, [])

  const logout = useCallback(() => {
    setUser(null)
  }, [])

  const switchRole = useCallback((role: UserRole) => {
    const userByRole = usuarios.find(u => u.rol === role)
    if (userByRole) {
      setUser(userByRole)
    }
  }, [])

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, isLoading, login, logout, switchRole }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
