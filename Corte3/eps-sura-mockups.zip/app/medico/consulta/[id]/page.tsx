"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { 
  ArrowLeft, 
  User, 
  FileText, 
  Pill, 
  Stethoscope,
  Calendar,
  Phone,
  Mail,
  MapPin,
  AlertCircle,
  Save,
  Printer,
  Plus,
  Trash2
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const patientData = {
  id: "1",
  name: "María García López",
  document: "1.234.567.890",
  birthDate: "1985-03-15",
  age: 41,
  gender: "Femenino",
  bloodType: "O+",
  phone: "300 123 4567",
  email: "maria.garcia@email.com",
  address: "Calle 45 #23-67, Medellín",
  eps: "EPS Salud",
  allergies: ["Penicilina", "Mariscos"],
  conditions: ["Hipertensión arterial", "Diabetes tipo 2"],
  currentMedications: [
    { name: "Losartán 50mg", dosage: "1 tableta cada 12 horas" },
    { name: "Metformina 850mg", dosage: "1 tableta con cada comida" }
  ],
  lastVisit: "2024-01-10",
  history: [
    { date: "2024-01-10", diagnosis: "Control de hipertensión", doctor: "Dr. Carlos Pérez" },
    { date: "2023-11-20", diagnosis: "Infección respiratoria", doctor: "Dra. Ana Rodríguez" },
    { date: "2023-09-05", diagnosis: "Control de diabetes", doctor: "Dr. Carlos Pérez" }
  ]
}

export default function ConsultaPage() {
  const params = useParams()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("consulta")
  const [prescriptions, setPrescriptions] = useState<Array<{
    medication: string
    dosage: string
    frequency: string
    duration: string
  }>>([])
  const [consultation, setConsultation] = useState({
    reason: "",
    symptoms: "",
    physicalExam: "",
    diagnosis: "",
    treatment: "",
    observations: "",
    nextAppointment: ""
  })

  const addPrescription = () => {
    setPrescriptions([...prescriptions, {
      medication: "",
      dosage: "",
      frequency: "",
      duration: ""
    }])
  }

  const removePrescription = (index: number) => {
    setPrescriptions(prescriptions.filter((_, i) => i !== index))
  }

  const updatePrescription = (index: number, field: string, value: string) => {
    const updated = [...prescriptions]
    updated[index] = { ...updated[index], [field]: value }
    setPrescriptions(updated)
  }

  const handleSave = () => {
    alert("Consulta guardada exitosamente")
    router.push("/medico/agenda")
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Consulta Médica</h1>
            <p className="text-muted-foreground">Paciente: {patientData.name}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Printer className="h-4 w-4 mr-2" />
            Imprimir
          </Button>
          <Button onClick={handleSave}>
            <Save className="h-4 w-4 mr-2" />
            Guardar Consulta
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Patient Info Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                Información del Paciente
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-2xl font-bold text-primary">MG</span>
                </div>
                <div>
                  <p className="font-semibold">{patientData.name}</p>
                  <p className="text-sm text-muted-foreground">CC: {patientData.document}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground">Edad</p>
                  <p className="font-medium">{patientData.age} años</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Género</p>
                  <p className="font-medium">{patientData.gender}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Tipo de sangre</p>
                  <p className="font-medium">{patientData.bloodType}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Última visita</p>
                  <p className="font-medium">{patientData.lastVisit}</p>
                </div>
              </div>

              <div className="pt-3 border-t space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{patientData.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{patientData.email}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{patientData.address}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-destructive/30 bg-destructive/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2 text-destructive">
                <AlertCircle className="h-5 w-5" />
                Alertas Médicas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-sm font-medium mb-2">Alergias:</p>
                <div className="flex flex-wrap gap-2">
                  {patientData.allergies.map((allergy) => (
                    <Badge key={allergy} variant="destructive">{allergy}</Badge>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-sm font-medium mb-2">Condiciones crónicas:</p>
                <div className="flex flex-wrap gap-2">
                  {patientData.conditions.map((condition) => (
                    <Badge key={condition} variant="outline" className="border-warning text-warning-foreground bg-warning/10">
                      {condition}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Pill className="h-5 w-5 text-primary" />
                Medicamentos Actuales
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {patientData.currentMedications.map((med, i) => (
                  <div key={i} className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-medium text-sm">{med.name}</p>
                    <p className="text-xs text-muted-foreground">{med.dosage}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Consultation Area */}
        <div className="lg:col-span-2">
          <Card>
            <CardContent className="p-0">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0">
                  <TabsTrigger 
                    value="consulta" 
                    className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
                  >
                    <Stethoscope className="h-4 w-4 mr-2" />
                    Consulta
                  </TabsTrigger>
                  <TabsTrigger 
                    value="prescripcion"
                    className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
                  >
                    <Pill className="h-4 w-4 mr-2" />
                    Prescripción
                  </TabsTrigger>
                  <TabsTrigger 
                    value="historial"
                    className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Historial
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="consulta" className="p-6 space-y-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="reason" className="text-base font-medium">Motivo de consulta</Label>
                      <Textarea
                        id="reason"
                        placeholder="Describa el motivo principal de la consulta..."
                        className="mt-2 min-h-[80px]"
                        value={consultation.reason}
                        onChange={(e) => setConsultation({...consultation, reason: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="symptoms" className="text-base font-medium">Síntomas</Label>
                      <Textarea
                        id="symptoms"
                        placeholder="Describa los síntomas reportados por el paciente..."
                        className="mt-2 min-h-[100px]"
                        value={consultation.symptoms}
                        onChange={(e) => setConsultation({...consultation, symptoms: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="physicalExam" className="text-base font-medium">Examen físico</Label>
                      <Textarea
                        id="physicalExam"
                        placeholder="Hallazgos del examen físico..."
                        className="mt-2 min-h-[100px]"
                        value={consultation.physicalExam}
                        onChange={(e) => setConsultation({...consultation, physicalExam: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="diagnosis" className="text-base font-medium">Diagnóstico</Label>
                      <Textarea
                        id="diagnosis"
                        placeholder="Diagnóstico presuntivo o definitivo..."
                        className="mt-2 min-h-[80px]"
                        value={consultation.diagnosis}
                        onChange={(e) => setConsultation({...consultation, diagnosis: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="treatment" className="text-base font-medium">Plan de tratamiento</Label>
                      <Textarea
                        id="treatment"
                        placeholder="Indique el plan de tratamiento..."
                        className="mt-2 min-h-[100px]"
                        value={consultation.treatment}
                        onChange={(e) => setConsultation({...consultation, treatment: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="observations" className="text-base font-medium">Observaciones adicionales</Label>
                      <Textarea
                        id="observations"
                        placeholder="Cualquier observación adicional..."
                        className="mt-2 min-h-[80px]"
                        value={consultation.observations}
                        onChange={(e) => setConsultation({...consultation, observations: e.target.value})}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="nextAppointment" className="text-base font-medium">Próxima cita</Label>
                        <Input
                          id="nextAppointment"
                          type="date"
                          className="mt-2"
                          value={consultation.nextAppointment}
                          onChange={(e) => setConsultation({...consultation, nextAppointment: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="prescripcion" className="p-6 space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Prescripción Médica</h3>
                    <Button onClick={addPrescription}>
                      <Plus className="h-4 w-4 mr-2" />
                      Agregar Medicamento
                    </Button>
                  </div>

                  {prescriptions.length === 0 ? (
                    <div className="text-center py-12 bg-muted/30 rounded-lg">
                      <Pill className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <p className="text-muted-foreground">No hay medicamentos en la prescripción</p>
                      <Button variant="link" onClick={addPrescription}>
                        Agregar medicamento
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {prescriptions.map((prescription, index) => (
                        <Card key={index} className="p-4">
                          <div className="flex items-start justify-between mb-4">
                            <span className="text-sm font-medium text-muted-foreground">
                              Medicamento #{index + 1}
                            </span>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive hover:text-destructive"
                              onClick={() => removePrescription(index)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="col-span-2">
                              <Label>Medicamento</Label>
                              <Input
                                placeholder="Nombre del medicamento"
                                className="mt-1"
                                value={prescription.medication}
                                onChange={(e) => updatePrescription(index, "medication", e.target.value)}
                              />
                            </div>
                            <div>
                              <Label>Dosis</Label>
                              <Input
                                placeholder="Ej: 500mg"
                                className="mt-1"
                                value={prescription.dosage}
                                onChange={(e) => updatePrescription(index, "dosage", e.target.value)}
                              />
                            </div>
                            <div>
                              <Label>Frecuencia</Label>
                              <Select
                                value={prescription.frequency}
                                onValueChange={(value) => updatePrescription(index, "frequency", value)}
                              >
                                <SelectTrigger className="mt-1">
                                  <SelectValue placeholder="Seleccionar" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="cada-6h">Cada 6 horas</SelectItem>
                                  <SelectItem value="cada-8h">Cada 8 horas</SelectItem>
                                  <SelectItem value="cada-12h">Cada 12 horas</SelectItem>
                                  <SelectItem value="cada-24h">Cada 24 horas</SelectItem>
                                  <SelectItem value="con-comidas">Con cada comida</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="col-span-2">
                              <Label>Duración del tratamiento</Label>
                              <Input
                                placeholder="Ej: 7 días"
                                className="mt-1"
                                value={prescription.duration}
                                onChange={(e) => updatePrescription(index, "duration", e.target.value)}
                              />
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="historial" className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Historial de Consultas</h3>
                  <div className="space-y-4">
                    {patientData.history.map((visit, i) => (
                      <Card key={i} className="p-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Calendar className="h-4 w-4 text-muted-foreground" />
                              <span className="font-medium">{visit.date}</span>
                            </div>
                            <p className="text-sm text-foreground">{visit.diagnosis}</p>
                            <p className="text-sm text-muted-foreground">{visit.doctor}</p>
                          </div>
                          <Button variant="outline" size="sm">
                            Ver detalles
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
