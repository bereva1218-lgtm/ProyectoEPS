'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import { 
  Heart, 
  Calendar, 
  FileText, 
  Pill, 
  User,
  Eye,
  EyeOff,
  AlertCircle,
  ChevronRight
} from 'lucide-react'

export default function LoginPage() {
  const router = useRouter()
  const { login, isAuthenticated, user } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (isAuthenticated && user) {
      router.push(`/${user.rol}`)
    }
  }, [isAuthenticated, user, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    const result = await login(email, password)
    
    if (!result.success) {
      setError(result.error || 'Error al iniciar sesion')
    }
    
    setIsLoading(false)
  }

  const demoAccounts = [
    { email: 'maria.garcia@email.com', role: 'Afiliado', desc: 'Portal del paciente' },
    { email: 'carlos.rodriguez@eps.com', role: 'Medico', desc: 'Portal medico' },
    { email: 'admin@eps.com', role: 'Admin', desc: 'Panel administrativo' },
  ]

  const features = [
    { icon: Calendar, title: 'Agenda tu cita', desc: 'Reserva citas medicas en linea de forma rapida' },
    { icon: FileText, title: 'Autorizaciones', desc: 'Solicita y consulta tus autorizaciones' },
    { icon: Pill, title: 'Medicamentos', desc: 'Gestiona tus formulas y reclamos' },
    { icon: User, title: 'Historial medico', desc: 'Accede a tu historia clinica digital' },
  ]

  return (
    <div className="min-h-screen flex">
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-sidebar relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-sidebar via-sidebar to-sidebar-accent opacity-90" />
        <div className="relative z-10 flex flex-col justify-between p-12 text-sidebar-foreground">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 bg-sidebar-primary rounded-xl flex items-center justify-center">
                <Heart className="w-6 h-6 text-sidebar-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">EPS Salud</h1>
                <p className="text-sidebar-foreground/70 text-sm">Portal de Servicios</p>
              </div>
            </div>
            
            <div className="max-w-md">
              <h2 className="text-3xl font-bold leading-tight mb-4">
                Tu salud, nuestra prioridad
              </h2>
              <p className="text-sidebar-foreground/80 text-lg leading-relaxed">
                Accede a todos tus servicios de salud desde un solo lugar. 
                Agenda citas, consulta autorizaciones y gestiona tus medicamentos.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mt-12">
            {features.map((feature, idx) => (
              <div key={idx} className="bg-sidebar-accent/30 backdrop-blur-sm rounded-xl p-4">
                <feature.icon className="w-6 h-6 text-sidebar-primary mb-2" />
                <h3 className="font-semibold text-sm mb-1">{feature.title}</h3>
                <p className="text-sidebar-foreground/70 text-xs">{feature.desc}</p>
              </div>
            ))}
          </div>

          <p className="text-sidebar-foreground/50 text-sm mt-8">
            Comprometidos con tu bienestar desde 1995
          </p>
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12 bg-background">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center justify-center gap-3 mb-8">
            <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
              <Heart className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">EPS Salud</h1>
              <p className="text-muted-foreground text-sm">Portal de Servicios</p>
            </div>
          </div>

          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-foreground mb-2">Bienvenido</h2>
            <p className="text-muted-foreground">Ingresa a tu cuenta para continuar</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                Correo electronico
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 text-base bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
                placeholder="correo@ejemplo.com"
                required
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-foreground mb-2">
                Contrasena
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 pr-12 text-base bg-card border border-input rounded-xl focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
                  placeholder="Ingresa tu contrasena"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showPassword ? 'Ocultar contrasena' : 'Mostrar contrasena'}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded border-input text-primary focus:ring-ring" />
                <span className="text-sm text-muted-foreground">Recordarme</span>
              </label>
              <a href="#" className="text-sm text-primary hover:underline">
                Olvide mi contrasena
              </a>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-primary text-primary-foreground py-3 px-4 rounded-xl font-semibold text-base hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {isLoading ? 'Ingresando...' : 'Ingresar'}
            </button>
          </form>

          {/* Demo accounts */}
          <div className="mt-8 pt-8 border-t border-border">
            <p className="text-sm text-muted-foreground text-center mb-4">
              Cuentas de demostracion
            </p>
            <div className="space-y-2">
              {demoAccounts.map((account) => (
                <button
                  key={account.email}
                  onClick={() => {
                    setEmail(account.email)
                    setPassword('demo123')
                  }}
                  className="w-full flex items-center justify-between p-3 bg-muted/50 hover:bg-muted rounded-xl transition-colors text-left group"
                >
                  <div>
                    <p className="font-medium text-sm text-foreground">{account.role}</p>
                    <p className="text-xs text-muted-foreground">{account.desc}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                </button>
              ))}
            </div>
          </div>

          <p className="text-center text-sm text-muted-foreground mt-8">
            ¿No tienes cuenta?{' '}
            <a href="#" className="text-primary font-medium hover:underline">
              Registrate aqui
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}
